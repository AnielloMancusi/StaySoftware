<?php

include_once "../beans/User.php";
include_once "../model/UserModel.php";

session_start();


$log=$_SESSION["log"];
if($log=$_SESSION["log"]) {
    $log=$_SESSION["log"];
    $codUt= $_SESSION["codUtente"];
    $nomeUt= $_SESSION["nomeUtente"];
    
}
$userModel = new UserModel();
$user = $userModel->getUserByCodUtente($codUt);




?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Profilo Utente</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="StaySoftware shop project">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../assets/styles/bootstrap4/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="../assets/styles/reg.css">
    <link href="../assets/plugins/fontawesome-free-5.0.1/css/fontawesome-all.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="../assets/styles/cart_styles.css">
    <link rel="stylesheet" type="text/css" href="../assets/styles/cart_responsive.css">

</head>


		<?php 
		      include "../fuction/menuL.php";
		?>
		


<form action="../control/ProfiloAdminControl.php" method='post' class='reg-form'>
    <div class="container">

        <p>E-mail: <input type="text" name="mod_mail_reg"  value=<?php echo $user->getMail()?> required ></p>
        <br/>
        <p>Password: <input type="password" name="mod_password_reg"  value=<?php echo $user->getPassword()?> required ></p>
        <br/>
        <p>Ripetere password: <input type="password" name="mod_passwordControl_reg"   ></p>
        <br/>
        <input type="submit", name="invia_dati", value="Conferma">
    </div>

</form>

</body>
</header>
</html>