<?php
/**
 * Created by PhpStorm.
 * User: Aniello Mancusi
 * Date: 13/06/2019
 * Time: 11:50
 */
session_start();
if($log=$_SESSION["log"]) {
    $log=$_SESSION["log"];
    $codUt= $_SESSION["codUtente"];
    $nomeUt= $_SESSION["nomeUtente"];
}

?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Lista Riparazioni</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="StaySoftware shop project">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../assets/styles/bootstrap4/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="../assets/styles/reg.css">
    <link href="../assets/plugins/fontawesome-free-5.0.1/css/fontawesome-all.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="../assets/styles/cart_styles.css">
    <link rel="stylesheet" type="text/css" href="../assets/styles/cart_responsive.css">

</head>

<header>

    <div class="super_container">

        <!-- Header -->

        <header class="header">

            <!-- Top Bar -->
     
            <div class="top_bar">
			<div class="container">
				<div class="row">
					<div class="col d-flex flex-row">
						<div class="top_bar_contact_item"><div class="top_bar_icon"><img src="../assets/images/phone.png" alt=""></div>+39 081 99 99 99</div>
						<div class="top_bar_contact_item"><div class="top_bar_icon"><img src="../assets/images/mail.png" alt=""></div><a href="assistenza@staysoftware.it">assistenza@staysoftware.it</a></div>
						<div class="top_bar_content ml-auto">
							
							<div class="top_bar_user">
								<div class="user_icon"><img src="../assets/images/user.svg" alt=""></div>
								 <div><a href="#">ADMIN</a></div>
        						 <div><a href="../control/LogoutControl.php">Log out</a></div>
							</div>
							</div>
						</div>
					</div>
				</div>
			</div>

            <!-- Header Main -->

            <div class="header_main">
                <div class="container">
                    <div class="row">

                        <!-- Logo -->
                        <div class="col-lg-2 col-sm-3 col-3 order-1">
                            <div class="logo_container">
                                <div class="logo"><a href="../view/home_admin.php"><img src="../assets/images/logo1.png" width="290" height="200"></a></div>
                            </div>
                        </div>

                    </div>

                    </head>
                </div>
            </div>
        </header>
    </div>
        <body>
        <div class="container">
        <table>
            <tr>
                <th>IdR &emsp;</th>
                <th>Descrizione &emsp;</th>
                <th>Prezzo &emsp;</th>
                <th>Stato &emsp;</th>
                <th>Codice Utente</th>
            </tr>
            <?php
            $conn = mysqli_connect("localhost", "root", "asdrofl123", "staysoftware");
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $sql = "SELECT * FROM riparazione WHERE stato='in riparazione'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                // output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["idR"].'&emsp;'. "</td><td>" . $row["descrizione"] .'&emsp;'. "</td><td>"
                        . $row["prezzo"]. '&emsp;'."</td><td>". $row["stato"].'&emsp;'. "</td><td>". $row["codUt"]. "</td></tr>";
                }
                echo "</table>";
            } else { echo "0 results"; }
            $conn->close();
            ?>
        </table>
        <form action="../control/StatoRiparazioneControl.php" method='post' class='reg-form'>
        <div class="container">


            <fieldset>
                <legend>Selezionare il Codice Riparazione</legend>
                <label>Codice Riparazione: </label>
                <?php 
                $conn = mysqli_connect("localhost", "root", "asdrofl123", "staysoftware");
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                $sql = "SELECT * FROM riparazione WHERE stato='in riparazione'";
                $result = $conn->query($sql);?>
                <!--Method One-->
                <p>
                    <select name="select_idR">

                        <?php while($row1 = mysqli_fetch_array($result)):;  ?>

                            <option value="<?php echo $row1[0];?>"><?php echo $row1[0];?></option>

                        <?php endwhile;?>

                    </select>
                </p>
                <label>Cambia Stato in: </label>
                
                <p>
                    <select name="select_stato">
  						<option value="accettato">Riparato</option>
  						<option value="rifiutato">Spedito</option>
  					</select>
                </p>
                <br>
                <p>
                    <input type="submit", name="invia_dati", value="conferma">
                </p>
            </fieldset>
        </div>


        </form>
        </div>
        </body>
