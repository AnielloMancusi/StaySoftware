<?php
/**
 * Created by PhpStorm.
 * User: Aniello Mancusi
 * Date: 13/06/2019
 * Time: 11:50
 */
session_start();
if($log=$_SESSION["log"]) {
    $log=$_SESSION["log"];
    $codUt= $_SESSION["codUtente"];
    $nomeUt= $_SESSION["nomeUtente"];
    
}

?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Inserisci prodotto</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="StaySoftware shop project">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../assets/styles/bootstrap4/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="../assets/styles/reg.css">
    <link href="../assets/plugins/fontawesome-free-5.0.1/css/fontawesome-all.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="../assets/styles/cart_styles.css">
    <link rel="stylesheet" type="text/css" href="../assets/styles/cart_responsive.css">

</head>

<header>

    <div class="super_container">

        <!-- Header -->

        <header class="header">

            <!-- Top Bar -->
     
            <div class="top_bar">
			<div class="container">
				<div class="row">
					<div class="col d-flex flex-row">
						<div class="top_bar_contact_item"><div class="top_bar_icon"><img src="../assets/images/phone.png" alt=""></div>+39 081 99 99 99</div>
						<div class="top_bar_contact_item"><div class="top_bar_icon"><img src="../assets/images/mail.png" alt=""></div><a href="assistenza@staysoftware.it">assistenza@staysoftware.it</a></div>
						<div class="top_bar_content ml-auto">
							
							<div class="top_bar_user">
								<div class="user_icon"><img src="../assets/images/user.svg" alt=""></div>
								 <div><a href="#">ADMIN</a></div>
        						 <div><a href="../control/LogoutControl.php">Log out</a></div>
							</div>
							</div>
						</div>
					</div>
				</div>
			</div>

            <!-- Header Main -->

            <div class="header_main">
                <div class="container">
                    <div class="row">

                        <!-- Logo -->
                        <div class="col-lg-2 col-sm-3 col-3 order-1">
                            <div class="logo_container">
                                <div class="logo"><a href="../view/home_admin.php"><img src="../assets/images/logo1.png" width="290" height="200"></a></div>
                            </div>
                        </div>

                    </div>

                    </head>
                </div>
            </div>
        </header>
    </div>
    <form action="../control/ProdottoControl.php" method='post' class='reg-form' enctype="multipart/form-data">
        <div class="container">


            <fieldset>
                <legend>Inserire Prodotto</legend>
                <label>Marca: </label>
                <input type="text" name="marca_prodotto" >

                <label>Modello: </label>
                <input type="text" name="modello_prodotto" >

                <label>Prezzo di acquisto: </label>
                <input type="text" name="prezzo_acquisto_prodotto" >

                <label>Prezzo di vendita: </label>
                <input type="text" name="prezzo_vendita_prodotto" >

                <label>Quantita': </label>
                <p>
                <input type="number" min="1" value="1" name="quantita_prodotto">
                </p>

                <label>Categoria: </label>
                <p>
                     <select name="select_categoria">
                     <option value="vuoto">Seleziona Categoria</option>
                     		<option value="computer">Computer</option>
                     		<option value="camera">Cameras & Photos</option>
                     		<option value="hardware">Hardware</option>
 							<option value="smartphone_tablet">Smartphone & Tablet</option>
 							<option value="tvaudio">TV & Audio</option>
  							<option value="console">VideoGames & Console</option>
  							<option value="accessori">Accessori</option>
  							
					</select> 
                </p>


                <label>Descrizione: </label>
                <p>
                <textarea name="descrizione_prodotto"></textarea>
                </p>

                <br>
                 <div class="form-group col-sm-11">
					<label for="userfile" class="col-sm-2 col-lg-2 control-label">Invia questo file: </label>
  					<div class="col-sm-9">
  						<input type="file" name="fileToUpload" id="fileToUpload">
   
                    </div>
                </div>
                
               
                <p>
                    <input type="submit" name="invia_dati" value="conferma">
                </p>
                 <?php $_SESSION["inserisciProdotto"]=true;?>
            </fieldset>
        </div>


    </form>


    </body>

</header>
</html>