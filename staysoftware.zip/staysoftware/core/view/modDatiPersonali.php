<?php

session_start();



if($log=$_SESSION["log"]) {
    $log=$_SESSION["log"];
    $codUt= $_SESSION["codUtente"];
    $nomeUt= $_SESSION["nomeUtente"];
}

?>


<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<title>StaySoftware</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Staysoftware shop project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="../assets/styles/bootstrap4/bootstrap.min.css">
<link href="../assets/plugins/fontawesome-free-5.0.1/css/fontawesome-all.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="../assets/plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="../assets/plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="../assets/plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="../assets/styles/product_styles.css">
<link rel="stylesheet" type="text/css" href="../assets/styles/product_responsive.css">
</head>

<body>


        <!-- Top Bar -->

        <?php
                                if($log){
                                    include "../fuction/menuL.php";
                                }
                                else{
                                    include "../fuction/menuNL.php";
                                }
                                ?>
<form action="../control/ProfiloUtenteControl.php" method='post' class='reg-form'>
    <div class="container">

		<p>Seleziona campo da modificare:    <br> <select name="scelta_req" required>
        <option value="Nome">Nome</option>
        <option value="Cognome">Cognome</option>
        <option value="CodiceF">Codice Fiscale</option>
        <option value="DataN">Data di nascita</option>
        <option value="ProvN">Provincia di nascita</option>
        <option value="ComuneN">Comune di nascita</option>
        <option value="Indirizzo">Indirizzo</option>
        <option value="ProvR">Provincia di residenza</option>
        <option value="ComR">Comune di residenza</option>
        <option value="CAP">C.A.P.</option>
        <option value="Telefono1">Telefono1</option>
        <option value="Telefono2">Telefono2</option>
        <br/>
        <br/>
        <p><br/>Inserisci nuovo <input type="text" name="mod_dati" required  ></p>
        
        <br>
        <input type="submit",  name="Conferma", value="Conferma">
       
    </div>

</form>

</body>

</html>