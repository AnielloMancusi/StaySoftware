<?php
/**
 * Created by PhpStorm.
 * User: Aniello Mancusi
 * Date: 13/06/2019
 * Time: 11:50
 */
session_start();
if($log=$_SESSION["log"]) {
    $log=$_SESSION["log"];
    $codUt= $_SESSION["codUtente"];
    $nomeUt= $_SESSION["nomeUtente"];
}

?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Controlla Richieste</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="StaySoftware shop project">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../assets/styles/bootstrap4/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="../assets/styles/reg.css">
    <link href="../assets/plugins/fontawesome-free-5.0.1/css/fontawesome-all.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="../assets/styles/cart_styles.css">
    <link rel="stylesheet" type="text/css" href="../assets/styles/cart_responsive.css">

</head>

<header>

  

     

                                    <?php
                             
                                    include "../fuction/menuL.php";
                               
								?>
                                   
                          
                    

         
        </header>
        <body>
        <div class="container">
        <fieldset>
        <legend>Richieste Preventivo Inviate</legend>
        <br>
        <p>
        <table>
            <tr>
                <th>IdR &emsp;</th>
                <th>Descrizione &emsp;</th>
                <th>Prezzo &emsp;</th>
                <th>Stato &emsp;</th>
                
            </tr>
            <?php
            $conn = mysqli_connect("localhost", "root", "asdrofl123", "staysoftware");
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $sql = "SELECT * FROM riparazione WHERE codUt=$codUt";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                // output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["idR"].'&emsp;'. "</td><td>" . $row["descrizione"] .'&emsp;'. "</td><td>"
                        . $row["prezzo"]. '&emsp;'."</td><td>". $row["stato"].'&emsp;'. "</td><td>";
                }
                echo "</table>";
            } else { echo "0 results"; }
            $conn->close();
            ?>
            
        </table>
        </p>
        <form action="../control/AccettaPreventivoControl.php" method='post' class='reg-form'>
        <div class="container">


            <fieldset>
                <legend>Selezionare la Richiesta Preventivo</legend>
                <label>Codice Riparazione: </label>
                <?php 
                $conn = mysqli_connect("localhost", "root", "asdrofl123", "staysoftware");
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                $sql = "SELECT * FROM riparazione WHERE codUt=$codUt";
                $result = $conn->query($sql);?>
                <!--Method One-->
               <p>
                    <select name="select_idR">

                        <?php while($row1 = mysqli_fetch_array($result)):;  ?>

                            <option value="<?php echo $row1[0];?>"><?php echo $row1[0];?></option>

                        <?php endwhile;?>

                    </select>
                </p>
                <label>Accettare il preventivo: </label>
                
                <p>
                    <select name="select_stato">
  						<option value="accettato">Accetta</option>
  						<option value="rifiutato">Rifiuta</option>
  					</select>
                </p>
                <br>
                <p>
                    <input type="submit" name="invia_dati" value="conferma">
                </p>
        </fieldset>
       </div>
     </body>
