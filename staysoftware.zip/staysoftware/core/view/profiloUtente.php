<?php 
include_once "../beans/User.php";
include_once "../model/UserModel.php";

session_start();


$log=$_SESSION["log"];
if($log=$_SESSION["log"]) {
    $log=$_SESSION["log"];
    $codUt= $_SESSION["codUtente"];
    $nomeUt= $_SESSION["nomeUtente"];
    
}
$userModel = new UserModel();
$user = $userModel->getUserByCodUtente($codUt);




?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Profilo Utente</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="StaySoftware shop project">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../assets/styles/bootstrap4/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="../assets/styles/reg.css">
    <link href="../assets/plugins/fontawesome-free-5.0.1/css/fontawesome-all.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="../assets/styles/cart_styles.css">
    <link rel="stylesheet" type="text/css" href="../assets/styles/cart_responsive.css">

</head>


		<?php 
		      include "../fuction/menuL.php";
		?>
		


<form action="../control/ProfiloUtenteControl.php" method='post' class='reg-form'>
    <div class="container">

        <p>Nome: <input type="text" name="mod_nome_reg" value=<?php echo $nomeUt?> required ></p>
        <br/>
        <p>Cognome: <input type="text" name="mod_cognome_reg" value=<?php echo $user->getCognome()?> required ></p>
        <br/>
        <p>Codice Fiscale: <input type="text" name="mod_cod_reg" value=<?php echo $user->getCodFiscale()?> required ></p>
        <br/>
        <div class="col-sm-2">
        <p>Data di Nascita:
            <input name="mod_dataNascita" id="mod_dataNascita" type="date" value=<?php echo $user->getDataNascita()?> class="form-control">
        </p>
        </div>
        <br/>
        

        <p>Provincia di nascita:    <br> <select name="mod_Provincia" required>
        <option value="<?php echo $user->getProvinciaResidenza()?>"><?php echo $user->getProvinciaResidenza()?></option>
        <option value="AG">Agrigento</option>
   	 	<option value="AO">Aosta</option>
    	<option value="AQ">L'Aquila</option>
    	<option value="AR">Arezzo</option>
    	<option value="AP">Ascoli-Piceno</option>
    	<option value="AT">Asti</option>
    	<option value="AV">Avellino</option>
    	<option value="BA">Bari</option>
    	<option value="BT">Barletta-Andria-Trani</option>
    	<option value="BL">Belluno</option>
    	<option value="BN">Benevento</option>
    	<option value="BG">Bergamo</option>
    	<option value="BI">Biella</option>
    	<option value="BO">Bologna</option>
    	<option value="BZ">Bolzano</option>
    	<option value="BS">Brescia</option>
    	<option value="BR">Brindisi</option>
    	<option value="CA">Cagliari</option>
    	<option value="CL">Caltanissetta</option>
    	<option value="CB">Campobasso</option>
    	<option value="CI">Carbonia Iglesias</option>
    	<option value="CE">Caserta</option>
    	<option value="CT">Catania</option>
    	<option value="CZ">Catanzaro</option>
    	<option value="CH">Chieti</option>
    	<option value="CO">Como</option>
    	<option value="CS">Cosenza</option>
    	<option value="CR">Cremona</option>
    	<option value="KR">Crotone</option>
    	<option value="CN">Cuneo</option>
    	<option value="EN">Enna</option>
    	<option value="FM">Fermo</option>
    	<option value="FE">Ferrara</option>
    	<option value="FI">Firenze</option>
    	<option value="FG">Foggia</option>
    	<option value="FC">Forli-Cesena</option>
    	<option value="FR">Frosinone</option>
    	<option value="GE">Genova</option>
    	<option value="GO">Gorizia</option>
    	<option value="GR">Grosseto</option>
    	<option value="IM">Imperia</option>
    	<option value="IS">Isernia</option>
    	<option value="SP">La Spezia</option>
    	<option value="LT">Latina</option>
    	<option value="LE">Lecce</option>
    	<option value="LC">Lecco</option>
    	<option value="LI">Livorno</option>
    	<option value="LO">Lodi</option>
    	<option value="LU">Lucca</option>
    	<option value="MC">Macerata</option>
    	<option value="MN">Mantova</option>
    	<option value="MS">Massa Carrara</option>
    	<option value="MT">Matera</option>
    	<option value="VS">Medio Campidano</option>
    	<option value="ME">Messina</option>
    	<option value="MI">Milano</option>
    	<option value="MO">Modena</option>
    	<option value="MB">Monza-Brianza</option>
    	<option value="NA">Napoli</option>
    	<option value="NO">Novara</option>
    	<option value="NU">Nuoro</option>
    	<option value="OG">Ogliastra</option>
    	<option value="OT">Olbia Tempio</option>
    	<option value="OR">Oristano</option>
    	<option value="PD">Padova</option>
    	<option value="PA">Palermo</option>
    	<option value="PR">Parma</option>
    	<option value="PV">Pavia</option>
    	<option value="PG">Perugia</option>
    	<option value="PU">Pesaro-Urbino</option>
    	<option value="PE">Pescara</option>
    	<option value="PC">Piacenza</option>
    	<option value="PI">Pisa</option>
    	<option value="PT">Pistoia</option>
    	<option value="PN">Pordenone</option>
    	<option value="PZ">Potenza</option>
    	<option value="PO">Prato</option>
    	<option value="RG">Ragusa</option>
    	<option value="RA">Ravenna</option>
    	<option value="RC">Reggio-Calabria</option>
    	<option value="RE">Reggio-Emilia</option>
    	<option value="RI">Rieti</option>
    	<option value="RN">Rimini</option>
    	<option value="RM">Roma</option>
    	<option value="RO">Rovigo</option>
    	<option value="SA">Salerno</option>
    	<option value="SS">Sassari</option>
    	<option value="SV">Savona</option>
    	<option value="SI">Siena</option>
    	<option value="SR">Siracusa</option>
    	<option value="SO">Sondrio</option>
    	<option value="TA">Taranto</option>
    	<option value="TE">Teramo</option>
    	<option value="TR">Terni</option>
    	<option value="TO">Torino</option>
    	<option value="TP">Trapani</option>
    	<option value="TN">Trento</option>
    	<option value="TV">Treviso</option>
    	<option value="TS">Trieste</option>
    	<option value="UD">Udine</option>
    	<option value="VA">Varese</option>
    	<option value="Ve">Venezia</option>
    	<option value="VB">Verbania</option>
    	<option value="VC">Vercelli</option>
    	<option value="VR">Verona</option>
    	<option value="VV">Vibo-Valentia</option>
    	<option value="VI">Vicenza</option>
    	<option value="VT">Viterbo</option>
  		</select>  </p>
        <br/>
        <p>Comune di nascita: <input type="text" name="mod_comuneN_reg"  value=<?php echo $user->getComuneNascita()?> required ></p>
        <br/>
        <p>Nazionalità: <input type="text" name="mod_nazionalita_reg"  value=<?php echo $user->getNazioneNascita()?> required ></p>
        <br/>
        <p>Indirizzo: <input type="text" name="mod_indirizzo_reg" value='<?php echo $user->getVia()?>' required  ></p>
        <br/>
        <p>Provincia di residenza:    <br> <select  name="mod_provinciaR_reg" required>
        <option value="<?php echo $user->getProvinciaResidenza()?>"><?php echo $user->getProvinciaResidenza()?></option>
        <option value="AG">Agrigento</option>
   	 	<option value="AO">Aosta</option>
    	<option value="AQ">L'Aquila</option>
    	<option value="AR">Arezzo</option>
    	<option value="AP">Ascoli-Piceno</option>
    	<option value="AT">Asti</option>
    	<option value="AV">Avellino</option>
    	<option value="BA">Bari</option>
    	<option value="BT">Barletta-Andria-Trani</option>
    	<option value="BL">Belluno</option>
    	<option value="BN">Benevento</option>
    	<option value="BG">Bergamo</option>
    	<option value="BI">Biella</option>
    	<option value="BO">Bologna</option>
    	<option value="BZ">Bolzano</option>
    	<option value="BS">Brescia</option>
    	<option value="BR">Brindisi</option>
    	<option value="CA">Cagliari</option>
    	<option value="CL">Caltanissetta</option>
    	<option value="CB">Campobasso</option>
    	<option value="CI">Carbonia Iglesias</option>
    	<option value="CE">Caserta</option>
    	<option value="CT">Catania</option>
    	<option value="CZ">Catanzaro</option>
    	<option value="CH">Chieti</option>
    	<option value="CO">Como</option>
    	<option value="CS">Cosenza</option>
    	<option value="CR">Cremona</option>
    	<option value="KR">Crotone</option>
    	<option value="CN">Cuneo</option>
    	<option value="EN">Enna</option>
    	<option value="FM">Fermo</option>
    	<option value="FE">Ferrara</option>
    	<option value="FI">Firenze</option>
    	<option value="FG">Foggia</option>
    	<option value="FC">Forli-Cesena</option>
    	<option value="FR">Frosinone</option>
    	<option value="GE">Genova</option>
    	<option value="GO">Gorizia</option>
    	<option value="GR">Grosseto</option>
    	<option value="IM">Imperia</option>
    	<option value="IS">Isernia</option>
    	<option value="SP">La Spezia</option>
    	<option value="LT">Latina</option>
    	<option value="LE">Lecce</option>
    	<option value="LC">Lecco</option>
    	<option value="LI">Livorno</option>
    	<option value="LO">Lodi</option>
    	<option value="LU">Lucca</option>
    	<option value="MC">Macerata</option>
    	<option value="MN">Mantova</option>
    	<option value="MS">Massa Carrara</option>
    	<option value="MT">Matera</option>
    	<option value="VS">Medio Campidano</option>
    	<option value="ME">Messina</option>
    	<option value="MI">Milano</option>
    	<option value="MO">Modena</option>
    	<option value="MB">Monza-Brianza</option>
    	<option value="NA">Napoli</option>
    	<option value="NO">Novara</option>
    	<option value="NU">Nuoro</option>
    	<option value="OG">Ogliastra</option>
    	<option value="OT">Olbia Tempio</option>
    	<option value="OR">Oristano</option>
    	<option value="PD">Padova</option>
    	<option value="PA">Palermo</option>
    	<option value="PR">Parma</option>
    	<option value="PV">Pavia</option>
    	<option value="PG">Perugia</option>
    	<option value="PU">Pesaro-Urbino</option>
    	<option value="PE">Pescara</option>
    	<option value="PC">Piacenza</option>
    	<option value="PI">Pisa</option>
    	<option value="PT">Pistoia</option>
    	<option value="PN">Pordenone</option>
    	<option value="PZ">Potenza</option>
    	<option value="PO">Prato</option>
    	<option value="RG">Ragusa</option>
    	<option value="RA">Ravenna</option>
    	<option value="RC">Reggio-Calabria</option>
    	<option value="RE">Reggio-Emilia</option>
    	<option value="RI">Rieti</option>
    	<option value="RN">Rimini</option>
    	<option value="RM">Roma</option>
    	<option value="RO">Rovigo</option>
    	<option value="SA">Salerno</option>
    	<option value="SS">Sassari</option>
    	<option value="SV">Savona</option>
    	<option value="SI">Siena</option>
    	<option value="SR">Siracusa</option>
    	<option value="SO">Sondrio</option>
    	<option value="TA">Taranto</option>
    	<option value="TE">Teramo</option>
    	<option value="TR">Terni</option>
    	<option value="TO">Torino</option>
    	<option value="TP">Trapani</option>
    	<option value="TN">Trento</option>
    	<option value="TV">Treviso</option>
    	<option value="TS">Trieste</option>
    	<option value="UD">Udine</option>
    	<option value="VA">Varese</option>
    	<option value="Ve">Venezia</option>
    	<option value="VB">Verbania</option>
    	<option value="VC">Vercelli</option>
    	<option value="VR">Verona</option>
    	<option value="VV">Vibo-Valentia</option>
    	<option value="VI">Vicenza</option>
    	<option value="VT">Viterbo</option>
  		</select>  </p>
        <br/>
        <p>Comune di residenza: <input type="text" name="mod_comuneR_reg"  value=<?php echo $user->getComuneResidenza()?> required  ></p>
        <br/>
        <p>C.A.P.: <input type="text" name="mod_cap_reg" value=<?php echo $user->getCap()?> required  ></p>
        <br/>
        <p>Sesso:    <br> <select  name="mod_sesso_reg" required>
        <option value="<?php echo $user->getSesso()?>"><?php echo $user->getSesso()?></option>
        <option value="Maschio">Maschio</option>
   	 	<option value="Femmina">Femmina</option>
        </select>  </p>
        <br/>
        <p>Telefono 1: <input type="text" name="mod_tel1_reg"  value=<?php echo $user->getTelefono1()?> required ></p>
        <br/>
        <p>Telefono 2: <input type="text" name="mod_tel2_reg"   value=<?php echo $user->getTelefono2()?> ></p>
        <br/>
        <p>Selezionare se si vuole cambiare passowrd o e-mail <Input type = "Radio" Name ='chgPoM' value="cambia"></p>
		<br/>
        <p>E-mail: <input type="text" name="mod_mail_reg"  value=<?php echo $user->getMail()?> required ></p>
        <br/>
        <p>Password: <input type="password" name="mod_password_reg"  value=<?php echo $user->getPassword()?> required ></p>
        <br/>
        <p>Ripetere password: <input type="password" name="mod_passwordControl_reg"   ></p>
        <br/>
        <input type="submit", name="invia_dati", value="Conferma">
    </div>

</form>

</body>
</header>
</html>