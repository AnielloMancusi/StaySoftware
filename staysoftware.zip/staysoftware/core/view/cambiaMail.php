<?php

session_start();


$log=$_SESSION["log"];
if($log=$_SESSION["log"]) {
    $log=$_SESSION["log"];
    $codUt= $_SESSION["codUtente"];
    $nomeUt= $_SESSION["nomeUtente"];
    $scelta=$_SESSION["scelta"];
}

?>


<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<title>StaySoftware</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Staysoftware shop project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="../assets/styles/bootstrap4/bootstrap.min.css">
<link href="../assets/plugins/fontawesome-free-5.0.1/css/fontawesome-all.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="../assets/plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="../assets/plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="../assets/plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="../assets/styles/product_styles.css">
<link rel="stylesheet" type="text/css" href="../assets/styles/product_responsive.css">
</head>

<body>


        <!-- Top Bar -->

        <?php
                                if($log){
                                    include "../fuction/menuL.php";
                                }
                                else{
                                    include "../fuction/menuNL.php";
                                }
                                ?>
<form action="../control/ProfiloUtenteControl.php" method='post' class='reg-form'>
    <div class="container">


     
        <p>Inserisci nuova e-mail: <input type="text" name="nuova_mail" required  ></p>
        <br/>
        <p>Inserire password: <input type="text" name="passwordControl_chgMail" required  ></p>
        <br/>
        <input type="submit",  name="invia_dati", value="Conferma">
        
       
    </div>

</form>
<?php 
$_SESSION["scelta"]="cambiaMail";
?>
</body>

</html>