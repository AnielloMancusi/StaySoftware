<?php

include_once "../model/ProdottoModel.php";

session_start();
$categoria = $_GET['categoria'];
setcookie("categoria", $categoria);

if($log=$_SESSION["log"]) {
    $log=$_SESSION["log"];
    $codUt= $_SESSION["codUtente"];
    $nomeUt= $_SESSION["nomeUtente"];
    $_SESSION["tab"]="si";
    $codProd=$_SESSION['idB'];
    
}else {
    $tab="no";
}

?>


<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<title>StaySoftware</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Staysoftware shop project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="../assets/styles/bootstrap4/bootstrap.min.css">
<link href="../assets/plugins/fontawesome-free-5.0.1/css/fontawesome-all.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="../assets/plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="../assets/plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="../assets/plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="../assets/styles/product_styles.css">
<link rel="stylesheet" type="text/css" href="../assets/styles/product_responsive.css">
</head>

<body>


        <!-- Top Bar -->

        <?php
                                if($log){
                                    include "../fuction/menuL.php";
                                }
                                else{
                                    include "../fuction/menuNL.php";
                                }
                                ?>
								

        <!-- Header Main -->



<form action="product2.php" method="POST" class='container'>
   <!-- Tabella prodotti -->
   <table class="table">
   <thead>
   <tr>
  <th>
  Nome
  </th>
  <th>
  Prezzo
  </th>
  <th>
  Immagine
  </th>
  <th>
  </th>
  </tr>
   
   </thead>

   <?php 
   
 $prodModel = new ProdottoModel();

   $listap=$prodModel->visualProdotti($categoria);
   echo "<tbody>";
   for($i=0;$i<count($listap);$i++){
      
       $idProdotto=$listap[$i]->getCodProdotto();
       $nomeProdotto = $listap[$i]->getMarca()."&nbsp".$listap[$i]->getModello();
       $prezzoProdotto = $listap[$i]->getPrezzoOUT();
       $immagineProdotto = $listap[$i]->getImmagine();
       $prova=array();
       $prova[$i]=$idProdotto;
       
      echo "<tr >
            
            <th>".$nomeProdotto."</th>
            <th>".$prezzoProdotto." &euro;</th>
            <th><img src=".$immagineProdotto." style=\"widht:50px;height:50px\"></th>
            <th><button name='idB'  value=$prova[$i]>Visualizza prodotto</button>  </th>
            </tr>";
            }
      echo "</tbody>";
      ?>
   </table>
   </form>
    <!-- Characteristics -->

	<div class="characteristics">
		<div class="container">
			<div class="row">

				<!-- Char. Item -->
				<div class="col-lg-3 col-md-6 char_col">

					<div class="char_item d-flex flex-row align-items-center justify-content-start">
						<div class="char_icon"><img src="../assets/images/char_1.png" alt=""></div>
						<div class="char_content">
							<div class="char_title">Spedizione Gratuita</div>
							<div class="char_subtitle">da &euro;50</div>
						</div>
					</div>
				</div>

				
			</div>
		</div>

	

	<!-- Brands -->

	<div class="brands">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="brands_slider_container">

						<!-- Brands Slider -->

						<div class="owl-carousel owl-theme brands_slider">

							<div class="owl-item"><div class="brands_item d-flex flex-column justify-content-center"><img src="../assets/images/brands_1.jpg" alt=""></div></div>
							<div class="owl-item"><div class="brands_item d-flex flex-column justify-content-center"><img src="../assets/images/brands_2.jpg" alt=""></div></div>
							<div class="owl-item"><div class="brands_item d-flex flex-column justify-content-center"><img src="../assets/images/brands_3.jpg" alt=""></div></div>
							<div class="owl-item"><div class="brands_item d-flex flex-column justify-content-center"><img src="../assets/images/brands_4.jpg" alt=""></div></div>
							<div class="owl-item"><div class="brands_item d-flex flex-column justify-content-center"><img src="../assets/images/brands_5.jpg" alt=""></div></div>
							<div class="owl-item"><div class="brands_item d-flex flex-column justify-content-center"><img src="../assets/images/brands_6.jpg" alt=""></div></div>
							<div class="owl-item"><div class="brands_item d-flex flex-column justify-content-center"><img src="../assets/images/brands_7.jpg" alt=""></div></div>
							<div class="owl-item"><div class="brands_item d-flex flex-column justify-content-center"><img src="../assets/images/brands_8.jpg" alt=""></div></div>

						</div>

						<!-- Brands Slider Navigation -->
						<div class="brands_nav brands_prev"><i class="fas fa-chevron-left"></i></div>
						<div class="brands_nav brands_next"><i class="fas fa-chevron-right"></i></div>

					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Newsletter -->

	<div class="newsletter">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="newsletter_container d-flex flex-lg-row flex-column align-items-lg-center align-items-center justify-content-lg-start justify-content-center">
						<div class="newsletter_title_container">
							<div class="newsletter_icon"><img src="../assets/images/send.png" alt=""></div>
							<div class="newsletter_title">Registrati per restare sempre aggiornato</div>
							<div class="newsletter_text"><p>...e riceverai uno sconto del 20% sul primo acquisto</p></div>
						</div>
						<div class="newsletter_content clearfix">
							<form action="#" class="newsletter_form">
								<input type="email" class="newsletter_input" required="required" placeholder="Inserisci indirizzo mail">
								<button class="newsletter_button">Registrati</button>
							</form>
							<div class="newsletter_unsubscribe_link"><a href="#">Rimuovi Account</a></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Footer -->

	<footer class="footer">
		<div class="container">
			<div class="row">

				<div class="col-lg-3 footer_col">
					<div class="footer_column footer_contact">
						<div class="logo_container">
							<div class="logo"><a href="#">StaySoftware</a></div>
						</div>
						<div class="footer_title">Hai bisogno di assistenza? </div>
						<div class="footer_phone">+39 081 99 99</div>
						<div class="footer_contact_text">
							<p>Roma</p>
							<p>Via Roma</p>
						</div>
						<div class="footer_social">
							<ul>
								<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="#"><i class="fab fa-twitter"></i></a></li>
								<li><a href="#"><i class="fab fa-youtube"></i></a></li>
								<li><a href="#"><i class="fab fa-google"></i></a></li>
								<li><a href="#"><i class="fab fa-vimeo-v"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>

	<!-- Copyright -->

	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col">

					<div class="copyright_container d-flex flex-sm-row flex-column align-items-center justify-content-start">
						<div class="copyright_content"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
							Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						</div>
						<div class="logos ml-sm-auto">
							<ul class="logos_list">
								<li><a href="#"><img src="../assets/images/logos_1.png" alt=""></a></li>
								<li><a href="#"><img src="../assets/images/logos_2.png" alt=""></a></li>
								<li><a href="#"><img src="../assets/images/logos_3.png" alt=""></a></li>
								<li><a href="#"><img src="../assets/images/logos_4.png" alt=""></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


    
</body>

