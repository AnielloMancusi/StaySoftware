<?php 
session_start();
if($log=$_SESSION["log"]) {
	$log=$_SESSION["log"];
	$codUt= $_SESSION["codUtente"];
	$nomeUt= $_SESSION["nomeUtente"];
}

?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Richiesta Preventivo</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="StaySoftware shop project">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../assets/styles/bootstrap4/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="../assets/styles/reg.css">
    <link href="../assets/plugins/fontawesome-free-5.0.1/css/fontawesome-all.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="../assets/styles/cart_styles.css">
    <link rel="stylesheet" type="text/css" href="../assets/styles/cart_responsive.css">

</head>

<header>

    <div class="super_container">

        <!-- Header -->

        <header class="header">

            <!-- Top Bar -->

            
                                    <?php
                            
                                    include "../fuction/menuL.php";
                          ?>
                       

        
    <form action="../control/RichiestaPreventivoControl.php" method='post' class='reg-form'>
        <div class="container">



            <p>Modello e Marca:
                <br>
                <textarea name="tipo_problema" rows="1" cols="50"></textarea>
            </p>
            <p>Descrivi il problema:
                <br>
                <textarea name="descrizione_problema" rows="4" cols="50"></textarea>
            </p>

            <input type="submit", name="invia_dati", value="Richiedi Preventivo">
        </div>

    </form>

    </body>

</header>
</html>