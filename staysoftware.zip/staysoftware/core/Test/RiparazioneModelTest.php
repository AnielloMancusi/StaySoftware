<?php


use PHPUnit\Framework\TestCase;
include_once "../../core/model/RiparazioneModel.php";
include_once "../../core/beans/Riparazione.php";

class RiparazioneModelTest extends TestCase
{

    public function testUpdatePreventivo()
    {
        $preventivo = new RiparazioneModel();
        $this->assertEquals(true, $preventivo->updatePreventivo("100", "accettato", ""));
    }

    public function testAccettaPreventivo()
    {
        $preventivo= new RiparazioneModel();
        $this->assertEquals(false, $preventivo->accettaPreventivo("", "accettato"));
    }

    public function testCambiaStatoRiparazione()
    {
        $preventivo = new RiparazioneModel();
        $this->assertEquals(true, $preventivo->updatePreventivo("100", "accettato", "1"));

    }
}
