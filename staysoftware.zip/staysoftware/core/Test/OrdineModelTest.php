<?php


use PHPUnit\Framework\TestCase;
include_once "../../core/model/OrdineModel.php";

class OrdineModelTest extends TestCase
{

    public function testUpdateData()
    {
        $ordine = new OrdineModel();
        $this->assertEquals(false, $ordine->updateData("1", "02", "1", "1"));
    }

    public function testAnnullaOrdine()
    {
        $ordine = new OrdineModel();
        $this->assertEquals(true, $ordine->annullaOrdine("2", "1", "2", "2"));
    }

}
