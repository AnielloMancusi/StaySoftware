<?php


use PHPUnit\Framework\TestCase;
include_once "../../core/model/ProdottoModel.php";

class ProdottoModelTest extends TestCase
{

    public function testUpdatePrezzoOUT()
    {
        $prodotto = new ProdottoModel();
        $this->assertEquals(true, $prodotto->updatePrezzoOUT("1", "350"));
    }

    public function testUpdateQuantita()
    {
        $prodotto = new ProdottoModel();
        $this->assertEquals(false, $prodotto->updateQuantita("1", "d"));
    }

    public function testRemoveProduct()
    {
        $prodotto = new ProdottoModel();
        $this->assertEquals(true, $prodotto->removeProduct("1"));
    }
}
