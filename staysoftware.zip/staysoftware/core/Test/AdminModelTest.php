<?php


use PHPUnit\Framework\TestCase;
include_once "../../core/model/AdminModel.php";
include_once "../../core/beans/User.php";
include_once "../../core/beans/Admin.php";
class AdminModelTest extends TestCase
{

    public function testGetAdminByMail()
    {
        $admin= new AdminModel();
        $amin=new Admin();
        $this->assertEquals( );
    }

    /*public function testEmailCheck()
    {
        $admin= new AdminModel();
        $this->assertEquals(true, $admin->emailCheck("vzito90@gmail.com"));
    }*/
}
