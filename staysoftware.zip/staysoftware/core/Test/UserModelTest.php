<?php


use PHPUnit\Framework\TestCase;

include_once "../../core/model/UserModel.php";

class UserModelTest extends TestCase
{

   /* public function testInsertUser()
    {
        public function testInsertUser()
    {
        $user = new User("", "giovanni", "verdi", "asdf", "02/02/1998", "na", "napoli", "italia",
            "via fantastica, 3", "na", "napoli", "08123", "maschio", "3332323231", "", "no",
            "ciao@ciaociaot.it", "cia0cia0");

        $userM = new UserModel;
        $this->assertEquals(false, $userM->insertUser($user));

    }*/

    public function testPasswordReg()
    {
        $user = new UserModel();
        $this->assertEquals(true, $user->passwordReg("cia0cia0", "cia0cia0"));

    }


    public function testEmailCheck()
    {
        $user = new UserModel();
        $this->assertEquals(false, $user->emailCheck("giova@giova.it"));

    }

    public function testPowerAdminCheck(){
        $user = new UserModel();
        $this->assertEquals(false, $user->powerAdminCheck("giova@ciao.it"));
    }
}
