<?php
/**
 * Created by PhpStorm.
 * User: Vik10
 * Date: 06/03/2019
 * Time: 15:25
 */




include_once "../beans/User.php";
include_once "../model/UserModel.php";
include_once "../beans/Admin.php";
include_once "../model/AdminModel.php";
session_start();


$userModel = new UserModel();
$adminModel = new AdminModel();

$mail = strip_tags($_POST["mail_log"]);
if($userModel->emailCheck($mail)!=null) {
    $user = $userModel->getUserByMail($mail);

    $password = strip_tags($_POST["password"]);
    if($userModel->passwordCheck($user, $password)){

        //Definisco le variabili di sessione dell'utente


        $_SESSION["message"] = "success";
        echo '<script language=javascript>document.location.href="../core/success.html"</script>';
    }else{
        $_SESSION["message"] = "password errata";
        $_SESSION["control"] = false;
        //session_destroy();
        echo '<script language=javascript>document.location.href="../passErrata.html"</script>';

    }

}
if($adminModel->emailCheck($mail)!=null) {
    $admin = $adminModel->getAdminByMail($mail);

    $password = strip_tags($_POST["password"]);

    //Controllo se la variabile $user è diversa da null

    //Controllo se la password coincide con l'utente che sta tentando l'accesso

    if(AdminModel::passwordCheck($admin, $password)){

        //Definisco le variabili di sessione dell'utente


        $_SESSION["message"] = "success";
        echo '<script language=javascript>document.location.href="../core/success.html"</script>';
    }else{
        $_SESSION["message"] = "password errata";
        $_SESSION["control"] = false;
        //session_destroy();
        echo '<script language=javascript>document.location.href="../passErrata.html"</script>';

    }
};