<?php
/**
 * Created by PhpStorm.
 * User: Aniello Mancusi
 * Date: 11/06/2019
 * Time: 15:57
 */
include_once "../beans/Riparazione.php";
include_once "../model/RiparazioneModel.php";




$validate = true;

$riparazioneModel = new RiparazioneModel();


if(isset($_POST["select_stato"]) && $_POST["select_stato"] != null){
    $select_stato = strip_tags($_POST["select_stato"]);
    
}else{
    
    $_SESSION["message"] = "Stato Accettato assente";
    echo $_SESSION["message"];
    $validate = false;
}

if(isset($_POST["select_idR"]) && $_POST["select_idR"] != null){
    $select_idR = strip_tags($_POST["select_idR"]);
}else{
    $_SESSION["message"] = "Codice riparazione assente";
    echo $_SESSION["message"];
    $validate = false;
}


if($validate == true){
  
    
    $riparazioneModel->cambiaStatoRiparazione($select_idR,$select_stato);
    
    echo '<script language=javascript>alert("Preventivo Accettato!")</script>';
    echo '<script language=javascript>document.location.href="../view/lista_riparazioni.php"</script>';
    
    
    
}else {
    echo '<script language=javascript>alert("Preventivo non inviato, riprovare!")</script>';
    echo '<script language=javascript>document.location.href="../view/lista_riparazioni.php"</script>';
}
