<?php 
/**
 * Created by PhpStorm.
 * User: Aniello Mancusi
 * Date: 11/06/2019
 * Time: 15:57
 */
include_once "../beans/Riparazione.php";
include_once "../model/RiparazioneModel.php";
$_SESSION["nomeUtente"];
$_SESSION["codUtente"];


$validate = true;

$riparazioneModel = new RiparazioneModel();


if(isset($_POST["select_stato"]) && $_POST["select_stato"] != null){
    $select_stato = strip_tags($_POST["select_stato"]);
    
}else{
    
    $_SESSION["message"] = "Stato Accettato assente";
    echo $_SESSION["message"];
    $validate = false;
}

if(isset($_POST["codRiparazione"]) && $_POST["codRiparazione"] != null){
    $select_idR = strip_tags($_POST["codRiparazione"]);
}else{
    $_SESSION["message"] = "Codice riparazione assente";
    echo $_SESSION["message"];
    $validate = false;
}


if($validate == true){
    if($select_stato == 'accettato'){
        $select_stato='in riparazione';
    }
   
    $riparazioneModel->accettaPreventivo($select_idR,$select_stato);
    
    echo '<script language=javascript>alert("Preventivo Accettato!")</script>';
    echo '<script language=javascript>document.location.href="../view/controlla_richieste.php"</script>';
    
    
    
}else {
    echo '<script language=javascript>alert("Preventivo non inviato, riprovare!")</script>';
    echo '<script language=javascript>document.location.href="../view/controlla_richieste.php"</script>';
}
