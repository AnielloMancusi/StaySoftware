<?php
/**
 * Created by PhpStorm.
 * User: Aniello Mancusi
 * Date: 07/06/2019
 * Time: 17:57
 */

include_once "../beans/Prodotto.php";
include_once "../model/ProdottoModel.php";
session_start();

$validate = true;

$prodottoModel = new ProdottoModel();

if(isset($_POST["select_option"]) && $_POST["select_option"] != null){
    $select_option = strip_tags($_POST["select_option"]);

}else{
    $_SESSION["message"] = "codProdotto assente";
    echo $_SESSION["message"];
    $validate = false;
}

if(isset($_POST["quantita_prodotto"]) && $_POST["quantita_prodotto"] != null){
    $quantita_prodotto = strip_tags($_POST["quantita_prodotto"]);
}else{
    $_SESSION["message"] = "Quantità prodotto assente";
    echo $_SESSION["message"];
    $validate = false;
}

if($validate == true){



    $prodottoModel->updateQuantita($select_option,$quantita_prodotto);

    $_SESSION["message"] = "Quantità prodotto aggiornata con successo";
    echo $_SESSION["message"];


}else {
    $_SESSION["message"] = $_SESSION["message"] . " -Quantità prodotto non aggiornata";
    echo '<script language=javascript>alert("Quantità prodotto non aggiornata, riprovare!")</script>';
}
