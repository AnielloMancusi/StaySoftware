<?php
include_once '../model/ProdottoModel.php';
include_once '../beans/Prodotto.php';
include_once '../model/OrdineModel.php';
include_once '../beans/Ordine.php';
include_once '../model/UserModel.php';
include_once '../beans/User.php';
session_start();
$conta=$_SESSION["contaCarr"];
$codUt= $_COOKIE['codUtC'];


$userM= new UserModel();
$prodM = new ProdottoModel();

$user=$userM->getUserByCodUtente($codUt);


if($conta==0){
    echo '<script language=javascript>document.location.href="../view/tabella_prodotti.php"</script>';
} else {
    $prodottoModel= new ProdottoModel();
    $ordineModel = new OrdineModel();
    
    
    $modello="";
    $quantita="";
    $prezzo=0;
    $prodotti=array();
    $carrello=$_COOKIE["carrello"];
   
    //print_r(explode(',', $carrello));
    $prodotti=(explode(',', $carrello));
    
    $totale_ordine=0;
    if($conta==0) {
        print_r($prodotti) ;
    }else {
        
        for($i=0; $i<$conta; $i=$i+5){
            $codProd=$prodotti[$i];
            $modello=$prodotti[$i+1];
            $quantita=$prodotti[$i+2];
            $prezzo=$prodotti[$i+3];
            
            $prodUp=$prodottoModel->getProductByCod($codProd);
            $quantProd= $prodUp->getQuantita();
            $quantAgg=$quantProd-$quantita;
            //query aggiorna prodotto
            $prodottoModel->updateQuantita($codProd, $quantAgg);
           
            //if($quantita>$quantitaP=$prodM->getProductByCod($codProdotto))
            
            
            $totale_ordine=$totale_ordine+$prezzo*$quantita;
        }
    }
    
    
    $data=date("y/m/d");
    $ordine = new Ordine(null, $codProd, $codUt, "in spedizione", $prezzo*$quantita, $data, $quantita, $user->getVia(), $user->getProvinciaResidenza(), $user->getComuneResidenza(), $user->getCap() );
    $ordineModel->insertOrder($ordine);
    setcookie("carrello", "", 0, "/");
    echo '<script language=javascript>alert("Prodotto acquistato con successo")</script>';
   echo '<script language=javascript>document.location.href="../view/home.php"</script>';

}