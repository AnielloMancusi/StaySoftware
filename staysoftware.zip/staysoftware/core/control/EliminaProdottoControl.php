<?php
/**
 * Created by PhpStorm.
 * User: Aniello Mancusi
 * Date: 10/06/2019
 * Time: 12:20
 */

include_once "../beans/Prodotto.php";
include_once "../model/ProdottoModel.php";
session_start();

$validate = true;

$prodottoModel = new ProdottoModel();

if(isset($_POST["select_option"]) && $_POST["select_option"] != null){
    $select_option = strip_tags($_POST["select_option"]);

}else{
    $_SESSION["message"] = "codProdotto assente";
    echo $_SESSION["message"];
    $validate = false;
}

if($validate == true){



    $prodottoModel->removeProduct($select_option);

    $_SESSION["message"] = "Prodotto eliminato con successo";
    echo $_SESSION["message"];


}else {
    $_SESSION["message"] = $_SESSION["message"] . " - Prodotto non eliminato";
    echo '<script language=javascript>alert("Prodotto non eliminato, riprovare!")</script>';
}
