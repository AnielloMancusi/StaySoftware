<?php
/**
 * Created by PhpStorm.
 * User: Aniello Mancusi
 * Date: 11/06/2019
 * Time: 15:57
 */
include_once "../beans/Riparazione.php";
include_once "../model/RiparazioneModel.php";
$_SESSION["nomeUtente"];
$_SESSION["codUtente"];


$validate = true;

$riparazioneModel = new RiparazioneModel();


if(isset($_POST["tipo_problema"]) && $_POST["tipo_problema"] != null){
    if(strlen(strip_tags($_POST["tipo_problema"]))>1 && strlen(strip_tags($_POST["tipo_problema"]))<30){
        $tipo_problema = strip_tags($_POST["tipo_problema"]);
    } else{
    
        $_SESSION["message"] = "Inserire un tipo di problema";   
        $validate = false;

    }
}

if(isset($_POST["descrizione_problema"]) && $_POST["descrizione_problema"] != null){
    if(strlen(strip_tags($_POST["descrizione_problema"]))>1 && strlen(strip_tags($_POST["descrizione_problema"]))<200){
        $descrizione_problema = strip_tags($_POST["descrizione_problema"]);
    }else{
        $_SESSION["message"] = "descrizione problema errata";
        $validate = false;
    }
} else {
    $_SESSION["message"] = "descrizione problema errata";
    $validate = false;
}


if($validate == true){

    $stato='in attesa';
    $preventivo=$tipo_problema;
    $preventivo.=$descrizione_problema;

    $riparazione= new Riparazione(null, $preventivo, NULL, $stato, NULL);

    $riparazioneModel->insertPreventivo($riparazione);

    echo '<script language=javascript>alert("Preventivo inviato!")</script>';
    echo '<script language=javascript>document.location.href="../view/home.php"</script>';



}else {
    echo '<script language=javascript>alert("Preventivo non inviato, riprovare!")</script>';
    echo '<script language=javascript>document.location.href="../view/richiesta_preventivo.php"</script>';
}
