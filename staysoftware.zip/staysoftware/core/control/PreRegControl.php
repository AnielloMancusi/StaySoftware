<?php 
/**
 * Created by PhpStorm.
 * User: Vik10
 * Date: 10/03/2019
 * Time: 17:35
 */
include_once "../beans/User.php";
include_once "../model/UserModel.php";
include_once "CodiceFiscaleControl.php";
session_start();



$userModel = new UserModel();
$user=$userModel;
$validate = true;
$admin= 'no';
//Controllo sul nome
if(isset($_POST["nome_reg"]) && $_POST["nome_reg"]!=null){

    if(strlen(strip_tags($_POST["nome_reg"]))>3 && strlen(strip_tags($_POST["nome_reg"]))<30){
        if(preg_match("/^[a-zA-Z]+$/",$_POST["nome_reg"])) {
            $nome = strip_tags($_POST["nome_reg"]);
        }else {
            echo '<script language=javascript>alert("Inserire un nome valido!")</script>';
            echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';
        }
        
    } else{ $validate=false;
    echo '<script language=javascript>alert("Inserire un nome corretto!")</script>';
    echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';}
}else{
    $_SESSION["message"] = "nome non inserito";
    echo $_SESSION["message"];
    $validate =false;
}



//Controllo sul cognome
if(isset($_POST["cognome_reg"]) && $_POST["cognome_reg"] != null){
    if(strlen(strip_tags($_POST["cognome_reg"]))>3 && strlen(strip_tags($_POST["cognome_reg"]))<30){
        if(preg_match("/^[a-zA-Z]+$/",$_POST["cognome_reg"])) {
            $cognome = strip_tags($_POST["cognome_reg"]);
        }else {
            echo '<script language=javascript>alert("Inserire un cognome valido!")</script>';
            echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';
            $validate=false;
        }
        
    } else{ $validate=false;
    echo '<script language=javascript>alert("Inserire un cognome corretto!")</script>';
    echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';}
}else{
    $_SESSION["message"] = "cognome non inserito";
    echo $_SESSION["message"];
    $validate =false;
}

//controllo sul codice fiscale
if(isset($_POST["cod_reg"]) && $_POST["cod_reg"] != null){
    if($userModel->codFiscaleCheck($_POST["cod_reg"])){
        $_SESSION["message"] = "codice fiscale già presente";
        echo $_SESSION["message"];
        $validate =false;
    }else{
        
        $codFiscale = strip_tags($_POST["cod_reg"]);
    }
}else{
    $_SESSION["message"] = "codice fiscale non inserito";
    echo $_SESSION["message"];
    $validate =false;
}

//controllo su data nascita
if(isset($_POST["dataNascita"]) && $_POST["dataNascita"] != null){
    $dataNascita = strip_tags($_POST["dataNascita"]);
}else{
    $_SESSION["message"] = "data nascita non inserita";
    echo $_SESSION["message"];
    $validate =false;
}

//controllo su provincia nascita
//provincia nascita

if(isset($_POST["provinciaN"]) && $_POST["provinciaN"] !=null){
    $provinciaNascita= $_POST["provinciaN"];
} else {
    echo '<script language=javascript>alert("Inserire una Provincia di nascita valida!")</script>';
    echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';
    $validate = false;
}
//controllo su comune di nascita
if(isset($_POST["comuneN_reg"]) && $_POST["comuneN_reg"] != null){
    if(strlen(strip_tags($_POST["comuneN_reg"]))>3 && strlen(strip_tags($_POST["comuneN_reg"]))<30){
        $comuneNascita = strip_tags($_POST["comuneN_reg"]);
    } else{ 
    $validate=false;
    echo '<script language=javascript>alert("Inserire un Comune di nascita valido!")</script>';
    echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';}
}else{
    echo '<script language=javascript>alert("Inserire un Comune di nascita!")</script>';
    echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';
    $validate =false;
}


//controllo su nazione di nascita
if(isset($_POST["nazionalita_reg"]) && $_POST["nazionalita_reg"] != null){
    if(strlen(strip_tags($_POST["nazionalita_reg"]))>3 && strlen(strip_tags($_POST["nazionalita_reg"]))<30){
        $nazioneNascita = strip_tags($_POST["nazionalita_reg"]);
    } else{ $validate=false;
    echo '<script language=javascript>alert("Inserire una nazionalità valida!")</script>';
    echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';}
}else{
    echo '<script language=javascript>alert("Inserire una nazionalità!")</script>';
    echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';
    $validate =false;
}


//controllo su via
if(isset($_POST["indirizzo_reg"]) && $_POST["indirizzo_reg"] != null){
    if(strlen(strip_tags($_POST["indirizzo_reg"]))>3 && strlen(strip_tags($_POST["indirizzo_reg"]))<=50){
        $via = strip_tags($_POST["indirizzo_reg"]);
    } else{ $validate=false;
    echo '<script language=javascript>alert("Inserire un indirizzo valido!")</script>';
    echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';}
}else{
    echo '<script language=javascript>alert("Inserire un indirizzo!")</script>';
    echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';
    $validate =false;
}


//controllo su provincia residenza
if(isset($_POST["provinciaR_reg"]) && $_POST["provinciaR_reg"] != null){
    $provinciaResidenza = strip_tags($_POST["provinciaR_reg"]);
}else{
    $_SESSION["message"] = "provincia residenza non inserita";
    echo $_SESSION["message"];
    $validate =false;
}

//controllo su comune di residenza
if(isset($_POST["comuneR_reg"]) && $_POST["comuneR_reg"] != null){
    if(strlen(strip_tags($_POST["comuneR_reg"]))>5 && strlen(strip_tags($_POST["comuneR_reg"]))<100){
        $comuneResidenza = strip_tags($_POST["comuneR_reg"]);
    } else{ $validate=false;
    echo '<script language=javascript>alert("Inserire un Comune di residenza valido!")</script>';
    echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';}
}else{
    echo '<script language=javascript>alert("Inserire il Comune di residenza!")</script>';
    echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';
    $validate =false;
}


//controllo cap
if(isset($_POST["cap_reg"]) && $_POST["cap_reg"] != null){
    if(isset($_POST["cap_reg"]) && $_POST["cap_reg"] != null){
        if(preg_match("/^(\d*)[0-9]$/", $_POST["cap_reg"])) {

            if(strlen(strip_tags($_POST["cap_reg"]))==5) {
                $cap = strip_tags($_POST["cap_reg"]);
                
            } else {
                echo '<script language=javascript>alert("Inserire un CAP VALIDO!")</script>';
                echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';
            }
            
        } else {
            echo '<script language=javascript>alert("Il C.A.P. deve contenere solo numeri!")</script>';
            echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';
        }
            
        } else{ $validate=false;
        echo '<script language=javascript>alert("Inserire un cap valido!")</script>';
        echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';}
    }else{
        echo '<script language=javascript>alert("Inserire un cap!")</script>';
        echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';
        $validate =false;
    }


//controllo sesso
if(isset($_POST["sesso_reg"]) && $_POST["sesso_reg"] != null){
    $sesso = strip_tags($_POST["sesso_reg"]);
}else{
    $_SESSION["message"] = "sesso non inserito";
    echo $_SESSION["message"];
    $validate =false;
}

//controllo se uno dei due telefoni è inserito
if((isset($_POST["tel1_reg"])) && $_POST["tel1_reg"] != null){
    if(isset($_POST["tel2_reg"]) && $_POST["tel2_reg"]!=null){    
        if(preg_match("/^(\d*)[0-9]$/", $_POST["tel1_reg"]) && preg_match("/^(\d*)[0-9]$/", $_POST["tel2_reg"])) {
            if(strlen(strip_tags($_POST["tel1_reg"]))>=10 && strlen(strip_tags($_POST["tel1_reg"]))<=11) {
                if(strlen(strip_tags($_POST["tel2_reg"]))>=10 && strlen(strip_tags($_POST["tel2_reg"]))<=11) {
                    
                    $telefono1 = strip_tags($_POST["tel1_reg"]);
                    $telefono2 = strip_tags($_POST["tel2_reg"]);
                } else {
                    
                }
            } else {
                $validate=false;
                echo '<script language=javascript>alert("Numero di telefono non valido2!")</script>';
                echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';
            }
        } else {
            $validate=false;
            echo '<script language=javascript>alert("Numero di telefono non valido2!")</script>';
            echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';
        }
        
        
    } else{
        if(preg_match("/^(\d*)[0-9]$/", $_POST["tel1_reg"])) {
            $telefono1 = strip_tags($_POST["tel1_reg"]);
        } else {
            $validate=false;
            echo '<script language=javascript>alert("Numero di telefono non valido!")</script>';
            echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';
        }
        
    }
        
} else {
    $validate=false;
    echo '<script language=javascript>alert("Numero di telefono non valido!")</script>';
    echo '<script language=javascript>document.location.href="../view/registrazione.html"</script>';
}

//controllo mail

if(isset($_POST["mail_reg"]) && $_POST["mail_reg"] != null){
    
    $email=trim($_POST["mail_reg"]);
    $num_at = count(explode( '@', $email )) - 1;
    if($num_at != 1) {
        //formato email errato;
        echo '<script language=javascript>alert("Inserire una e-mail valida1!")</script>';
        $validate = false;
    } else if(strpos($email,';') || strpos($email,',') || strpos($email,' ')) {
        //formato email errato;
        echo '<script language=javascript>alert("Inserire una e-mail valida!2")</script>';
        $validate = false;
    } else if(!preg_match( '/^[\w\.\-]+@\w+[\w\.\-]*?\.\w{1,4}$/', $email)) {
        //formato email errato;
        echo '<script language=javascript>alert("Inserire una e-mail valida!3")</script>';
        $validate = false;
    } else if($userModel->emailCheck($_POST["mail_reg"])){
        echo '<script language=javascript>alert("E-mail già presente!")</script>';
    }
    
    
    
} else {
    //inserisci una mail
    echo '<script language=javascript>alert("Inserire una e-mail valida!4")</script>';
    $validate = false;
}



//controllo password
if(isset($_POST["password_reg"]) && $_POST["password_reg"] != null){
    if(isset($_POST["passwordControl_reg"]) && $_POST["passwordControl_reg"] != null) {
        $pass1 = $_POST["password_reg"];
        $passC = $_POST["passwordControl_reg"];
        if($pass1==$passC) {
            //CONTROLLA PREG_MATCH per i simboli
            if(strlen($_POST["password_reg"])>7 && strlen($_POST["password_reg"])<20){
                if(!preg_match("/^[a-z0-9]+$/i", $_POST["password_reg"])){
                    echo '<script language=javascript>alert("La password deve contenere lettere e numeri!")</script>';
                    $validate = false;
                }
                
            }else{
                echo '<script language=javascript>alert("La password deve contenere almeno 6 caratteri!")</script>';
                $validate =false;
            }
        } else {
            echo '<script language=javascript>alert("Le password non corrispondono!")</script>';
            $validate =false;
        }
        
    }else{
        echo '<script language=javascript>alert("Inserisci una password!")</script>';
        $validate =false;
    }
}


//controllo generale
if($validate == true){
    $user = new User(null, $nome, $cognome, $codFiscale, $dataNascita, $provinciaNascita, $comuneNascita, $nazioneNascita, $via, $provinciaResidenza,
        $comuneResidenza, $cap, $sesso, $telefono1, $telefono2, $admin, $email, $pass1);
    $userModel->insertUser($user);
    $_SESSION["message"] = "utente inserito con successo";
    $_SESSION["message"] = "utente inserito con successo";
    echo $_SESSION["message"];
    echo '<script language=javascript>alert("Utente inserito con successo")</script>';
    echo '<script language=javascript>document.location.href="../index.php"</script>';
}else {
    $_SESSION["message"] = $_SESSION["message"] . " - Utente non inserito";
    echo $_SESSION["message"];
    echo '<script language=javascript>alert("Utente non registrato, riprovare!")</script>';
    echo '<script language=javascript>document.location.href="../index.php"</script>';
}
