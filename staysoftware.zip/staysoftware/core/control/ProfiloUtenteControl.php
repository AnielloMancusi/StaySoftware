<?php
include_once "../beans/User.php";
include_once "../model/UserModel.php";
include_once "CodiceFiscaleControl.php";

session_start();
$log=$_SESSION["log"];
if($log==$_SESSION["log"]) {
    $log=$_SESSION["log"];
    $codUt= $_SESSION["codUtente"];
}


$userModel = new UserModel();
$validate = true;
$admin= 'no';
$user=$userModel->getUserByCodUtente($codUt);


//controlla nome
if(isset($_POST["mod_nome_reg"]) && $_POST["mod_nome_reg"] != null){
    $mod_nomeReg=$_POST["mod_nome_reg"];
    if(strlen($mod_nomeReg)< 3 || strlen($mod_nomeReg) >30){
        //nome errato
        echo '<script language=javascript>alert("Inserire un nome corretto!")</script>';
        echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
    } else {
        if($mod_nomeReg!=$user->getNome()){
            $userModel->updateNome($codUt, $mod_nomeReg);
            echo '<script language=javascript>alert("Nome cambiato!")</script>';
            echo '<script language=javascript>document.location.href="../view/home.php"</script>';
            
        }
    }
    
} else {
    echo '<script language=javascript>alert("Inserire un nome!")</script>';
    echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
    $validate = false;
}

if(isset($_POST["mod_cognome_reg"]) && $_POST["mod_cognome_reg"] != null){
    $mod_cognomeReg=$_POST["mod_cognome_reg"];
    if($mod_cognomeReg!=$user->getCognome()){
        //inserisci nuovo cognome
        
        if(strlen(mod_cognome_reg)< 3 || strlen(mod_cognome_reg) >30){
            //cognome errato
            echo '<script language=javascript>alert("Inserire un cognome corretto!")</script>';
            echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
        } else {
            $userModel->updateCognome($codUt, $mod_cognomeReg);
            echo '<script language=javascript>alert("Cognome cambiato!")</script>';
            echo '<script language=javascript>document.location.href="../view/home.php"</script>';
            
        }
    }
    
} else {
    echo '<script language=javascript>alert("Inserire un cognome!")</script>';
    echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
    $validate = false;
}

//codice fiscale
if(isset($_POST["mod_cod_reg"]) && $_POST["mod_cod_reg"] != null){
    $mod_cod_reg=$_POST["mod_cod_reg"];
    if(ControllaCF($mod_cod_reg)==true){
        if($mod_cod_reg!=$user->getCodFiscale()){
            $userModel->updateCf($codUt, $mod_cod_reg);
        }
    } else {
        echo '<script language=javascript>alert("Inserire un codice fiscale corretto!")</script>';
        echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
    }
   } else {
    echo '<script language=javascript>alert("Inserire un codice fiscale!")</script>';
    echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
    $validate = false;
}

//data nascita
if(isset($_POST["mod_dataNascita"]) && $_POST["mod_dataNascita"] !=null){
    $mod_dataNascita= $_POST["mod_dataNascita"];
    if($mod_dataNascita!=$user->getDataNascita()){
        $userModel->updateDataN($codUt, $mod_dataNascita);
    }
} else {
    echo '<script language=javascript>alert("Inserire una data di nascita valida!")</script>';
    echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
}

//provincia nascita
if(isset($_POST["mod_Provincia"]) && $_POST["mod_Provincia"] !=null){
    $mod_Provincia= $_POST["mod_Provincia"];
    if($mod_Provincia!=$user->getProvinciaNascita()){
        $userModel->updateProvN($codUt, $mod_Provincia);
    }
} else {
    echo '<script language=javascript>alert("Inserire una Provincia di nascita valida!")</script>';
    echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
}

//comune nascita
if(isset($_POST["mod_comuneN_reg"]) && $_POST["mod_comuneN_reg"] !=null){
    $mod_comuneN_reg= $_POST["mod_comuneN_reg"];
    if($mod_comuneN_reg!=$user->getComuneNascita()){
        $userModel->updateComuneN($codUt, $mod_comuneN_reg);
    }
} else {
    echo '<script language=javascript>alert("Inserire una Provincia di nascita valida!")</script>';
    echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
}

//nazionalità
if(isset($_POST["mod_nazionalita_reg"]) && $_POST["mod_nazionalita_reg"] !=null){
    $mod_nazionalita_reg= $_POST["mod_nazionalita_reg"];
    if($mod_nazionalita_reg!=$user->getNazioneNascita()){
        $userModel->updateNazionalità($codUt, $mod_nazionalita_reg);
    }
} else {
    echo '<script language=javascript>alert("Inserire una Nazionalità valida!")</script>';
    echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
}

//indirizzo
if(isset($_POST["mod_indirizzo_reg"]) && $_POST["mod_indirizzo_reg"] !=null){
    if(strlen(trim($_POST["mod_indirizzo_reg"]))>3 && strlen(trim($_POST["mod_indirizzo_reg"]))<=50) {
            if(!preg_match("/^(\d*)[0-9]$/", $_POST["mod_indirizzo_reg"])) {
                $mod_indirizzo_reg= $_POST["mod_indirizzo_reg"];
                if($mod_indirizzo_reg!=$user->getVia()){
                    if($userModel->updateIndirizzo($codUt, $mod_indirizzo_reg)){
                        echo '<script language=javascript>alert("Indirizzo cambiato!")</script>';
                        echo '<script language=javascript>document.location.href="../view/home.php"</script>';
                    }
                }
            } else {
                echo '<script language=javascript>alert("Inserire un indirizzo valido1!")</script>';
                echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
            }
    }else {
        echo '<script language=javascript>alert("Inserire un indirizzo valido2!")</script>';
        echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
    }
        
}
//provincia residenza
if(isset($_POST["mod_provinciaR_reg"]) && $_POST["mod_provinciaR_reg"] !=null){
    $mod_provinciaR_reg= $_POST["mod_provinciaR_reg"];
    if($mod_provinciaR_reg!=$user->getProvinciaResidenza()){
        $userModel->updateProvN($codUt, $mod_provinciaR_reg);
    }
} else {
    echo '<script language=javascript>alert("Inserire una Provincia di residenza valida!")</script>';
    echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
}

//comune residenza
if(isset($_POST["mod_comuneR_reg"]) && $_POST["mod_comuneR_reg"] !=null){
    $mod_comuneR_reg= $_POST["mod_comuneR_reg"];
    if($mod_comuneR_reg!=$user->getComuneResidenza()){
        $userModel->updateComuneN($codUt, $mod_comuneR_reg);
    }
} else {
    echo '<script language=javascript>alert("Inserire un Comune di residenza valido!")</script>';
    echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
}

//cap
if(isset($_POST["mod_cap_reg"]) && $_POST["mod_cap_reg"] !=null){
    $mod_cap_reg= $_POST["mod_cap_reg"];
    if($mod_cap_reg!=$user->getCap()){
        if(strlen($mod_cap_reg)==5) {
            $userModel->updateComuneN($codUt, $mod_cap_reg);
        }else {
            echo '<script language=javascript>alert("Inserire un CAP valido!")</script>';
            echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
        }
    }
} else {
    echo '<script language=javascript>alert("Inserire un CAP valido!")</script>';
    echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
}

//sesso
if(isset($_POST["mod_sesso_reg"]) && $_POST["mod_sesso_reg"] !=null){
    $mod_sesso_reg= $_POST["mod_sesso_reg"];
    if($mod_sesso_reg!=$user->getSesso()){
        $userModel->updateSesso($codUt, $mod_sesso_reg);
    }
} else {
    echo '<script language=javascript>alert("Inserire un sesso valido!")</script>';
    echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
}

//tel1

if(isset($_POST["mod_tel1_reg"]) && $_POST["mod_tel1_reg"] !=null){
    if(preg_match("/^(\d*)[0-9]$/", $_POST["mod_tel1_reg"])) {
        $mod_tel1_reg= $_POST["mod_tel1_reg"];
        
            if(strlen($mod_tel1_reg)>=10 && strlen($mod_tel1_reg)<=11){
                if($mod_tel1_reg!=$user->getTelefono1()) {
                    if($userModel->updateTel1($codUt, $mod_tel1_reg)){
                        echo '<script language=javascript>alert("Numero di telefono cambiato!")</script>';
                        echo '<script language=javascript>document.location.href="../view/home.php"</script>';
                    }
                }
                
            } else {
            echo '<script language=javascript>alert("Inserire un numero di telefono1 valido1!")</script>';
            echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
        }
    } else {
        echo '<script language=javascript>alert("Inserire un numero di telefono1 valido4!")</script>';
        echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
    }
    
} else {
    echo '<script language=javascript>alert("Inserire un numero di telefono1 valido3!")</script>';
    echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
}
 

//tel2
if(isset($_POST["mod_tel2_reg"]) && $_POST["mod_tel2_reg"] !=null){
    if(preg_match("/^(\d*)[0-9]$/", $_POST["mod_tel2_reg"])) {
        $mod_tel2_reg= $_POST["mod_tel2_reg"];
        if($mod_tel2_reg!=$user->getTelefono2()){
            if(strlen($mod_tel2_reg)>=10 && strlen($mod_tel2_reg)<=11){
                if($userModel->updateTel2($codUt, $mod_tel2_reg)){
                    echo '<script language=javascript>alert("Numero di telefono cambiato!")</script>';
                    echo '<script language=javascript>document.location.href="../view/home.php"</script>';
                }
            }
        } else {
            echo '<script language=javascript>alert("Inserire un numero di telefono2 valido1!")</script>';
            echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
        }
    } else {
        echo '<script language=javascript>alert("Inserire un numero di telefono2 valido2!")</script>';
        echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
    }
    
} 


if(isset($_POST["mod_mail_reg"]) && $_POST["mod_mail_reg"]!=null) {
    if($_POST["mod_mail_reg"]!=$userModel->getMailByCodUtente($codUt)){
        $mod_mail_reg=trim($_POST["mod_mail_reg"]);
        $num_at = count(explode( '@', $mod_mail_reg )) - 1;
        if($num_at!=1) {
            //formato errato
            echo '<script language=javascript>alert("Inserire una e-mail valida1!")</script>';
            echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
            $validate = false;
        } else if (strpos($mod_mail_reg, ';') || strpos($mod_mail_reg, ',') || strpos($mod_mail_reg, ' ')) {
            //formato errato
            echo '<script language=javascript>alert("Inserire una e-mail valida1!")</script>';
            echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
            $validate = false;
        } else if(!preg_match( '/^[\w\.\-]+@\w+[\w\.\-]*?\.\w{1,4}$/', $mod_mail_reg)){
            //formato errato
            echo '<script language=javascript>alert("Inserire una e-mail valida1!")</script>';
            echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
            $validate = false;
        }
        
        if($mod_mail_reg!=$user->getMail() && $validate==true){
            if(isset($_POST["mod_password_reg"]) && $_POST["mod_password_reg"]!=null){
                if(isset($_POST["mod_passwordControl_reg"]) && $_POST["mod_passwordControl_reg"]!=null){
                    $pass1=$_POST["mod_password_reg"];
                    $pass2=$_POST["mod_passwordControl_reg"];
                    if($pass1==$user->getPassword()){
                        if($userModel->passwordReg($pass1, $pass2)){
                            $userModel->updateMail($codUt, $mod_mail_reg);
                        } else {
                            //le password non coincidono
                            echo '<script language=javascript>alert("Le password non coincidono!")</script>';
                            echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
                        }
                    } else {
                        //password errata
                        echo '<script language=javascript>alert("Password errata!")</script>';
                        echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
                    }
                } else {
                    //inserisci password di controllo
                    echo '<script language=javascript>alert("Inserire la password di controllo!")</script>';
                    echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
                }
            } else{
                //inserisci password
                echo '<script language=javascript>alert("Inserire la password!")</script>';
                echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
            }
            echo '<script language=javascript>alert("Email cambiata!")</script>';
            echo '<script language=javascript>document.location.href="../view/home.php"</script>';
            
        }
    } 


}


//password
if(isset($_POST["mod_mail_reg"]) && $_POST["mod_mail_reg"] !=null){
    if($_POST["mod_mail_reg"]==$userModel->getMailByCodUtente($codUt)) {
        if(isset($_POST["mod_password_reg"]) && $_POST["mod_password_reg"]!=null) {
            if($_POST["mod_password_reg"]!=$user->getPassword()) {
                if(isset($_POST["mod_passwordControl_reg"]) && $_POST["mod_passwordControl_reg"]!=null) {
                    $pass1=$_POST["mod_password_reg"];
                    $pass2=$_POST["mod_passwordControl_reg"];
                    
                        if($userModel->passwordReg($pass1, $pass2)) {
                            $userModel->updatePassword($codUt, $pass1);
                            echo '<script language=javascript>document.location.href="../view/home.php"</script>';
                        } else {
                            echo '<script language=javascript>alert("La password non rispetta il formato richiesto!")</script>';
                            echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
                        }
                    
                    
                } else {
                    echo '<script language=javascript>alert("Inserire la password di controllo!")</script>';
                    echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
                }
                
            } else {
                echo '<script language=javascript>alert("Inserisci la password!")</script>';
                echo '<script language=javascript>document.location.href="../view/profiloUtente.php"</script>';
            }
            
        }
            }
            
        
    
}


?>
