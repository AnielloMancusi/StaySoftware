<?php
/**
 * Created by PhpStorm.
 * User: stefanoforesta
 * Date: 07/06/18
 * Time: 20:17
 */

session_start();

unset($_SESSION["user"]);
unset($_SESSION["username"]);
unset($_SESSION["control"]);
session_destroy();
echo '<script language=javascript>document.location.href="../index.php"</script>';