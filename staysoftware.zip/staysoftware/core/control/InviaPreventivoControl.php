<?php
include_once "../beans/Riparazione.php";
include_once "../model/RiparazioneModel.php";


$validate = true;

$riparazioneModel = new RiparazioneModel();



if(isset($_POST["select_idR"]) && $_POST["select_idR"] != null){
    $select_idR = strip_tags($_POST["select_idR"]);
    
}else{
    
    echo '<script language=javascript>alert("Codice preventivo assente!")</script>';
    echo '<script language=javascript>document.location.href="../view/lista_preventivi.php"</script>';
    $validate = false;
}

if(isset($_POST["select_stato"]) && $_POST["select_stato"] != null){
    if($_POST["select_stato"]=="accettato" || $_POST["select_stato"]=="rifiutato") {
        $select_stato = strip_tags($_POST["select_stato"]);
    } else {
        echo '<script language=javascript>alert("Accettare o rifiutare il preventivo!")</script>';
        echo '<script language=javascript>document.location.href="../view/lista_preventivi.php"</script>';
        $validate = false;
    }
    
}else{
    echo '<script language=javascript>alert("Stato preventivo assente!")</script>';
    echo '<script language=javascript>document.location.href="../view/lista_preventivi.php"</script>';
    $validate = false;
}
if(isset($_POST["prezzo_preventivo"]) && $_POST["prezzo_preventivo"] != null){
    if(!preg_match("/^(\d*)-(\d*)[0-9]$/", $_POST["prezzo_preventivo"])) {
        if(strlen($_POST["prezzo_preventivo"])>1 && strlen($_POST["prezzo_preventivo"])<5){
            $prezzo_preventivo = strip_tags($_POST["prezzo_preventivo"]);
        } else {
            echo '<script language=javascript>alert("Prezzo preventivo non valido!")</script>';
            echo '<script language=javascript>document.location.href="../view/lista_preventivi.php"</script>';
            $validate = false;
        }
    } else {
        echo '<script language=javascript>alert("Prezzo preventivo non valido!")</script>';
        echo '<script language=javascript>document.location.href="../view/lista_preventivi.php"</script>';
        $validate = false;
    }
    
}else{
    echo '<script language=javascript>alert("Prezzo preventivo assente!")</script>';
    echo '<script language=javascript>document.location.href="../view/lista_preventivi.php"</script>';
    $validate = false;
}


if($validate == true){
    

    $riparazioneModel->updatePreventivo($prezzo_preventivo,$select_stato,$select_idR);
    
    echo '<script language=javascript>alert("Preventivo inviato!")</script>';
    echo '<script language=javascript>document.location.href="../view/home.php"</script>';
    
    
    
}else {
    echo '<script language=javascript>alert("Preventivo non inviato, riprovare!")</script>';
    echo '<script language=javascript>document.location.href="../view/richiesta_preventivo.php"</script>';
}
