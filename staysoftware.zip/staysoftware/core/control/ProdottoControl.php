<?php


include_once "../beans/Prodotto.php";
include_once "../model/ProdottoModel.php";
session_start();
$aggPrezz=$_SESSION["aggiornaPrezzo"];
$codPUpdate=$_SESSION["codPrUpdatePrezzo"];
if(isset($_SESSION["inserisciProdotto"])) {
    $inserisciProdotto=$_SESSION["inserisciProdotto"];
}
$validate = true;

$prodottoModel = new ProdottoModel();
if($aggPrezz==true){
    $prodottoModel->updatePrezzoOUT($codPUpdate, $_POST["prezzo_prodotto"]);
    
}
if($_SESSION["inserisciProdotto"]==true) {
    
    if(isset($_POST["marca_prodotto"]) && $_POST["marca_prodotto"] != null){
        if(preg_match("/^[a-zA-Z]+$/",$_POST["marca_prodotto"])) {
            if(strlen(strip_tags($_POST["marca_prodotto"]))>1 && strlen(strip_tags($_POST["marca_prodotto"]))<15) {
                $marca = strip_tags($_POST["marca_prodotto"]);
            } else {
                $validate=false;
                echo '<script language=javascript>alert("Marca non valida1!")</script>';
                echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
            }
        } else {
            $validate=false;
            echo '<script language=javascript>alert("Marca non valida2!")</script>';
            echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
        }
        
        
    }else{
        $_SESSION["message"] = "marca assente";
        $validate=false;
        echo '<script language=javascript>alert("Marca non valida3!")</script>';
        echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
        $validate = false;
    }
    
    if(isset($_POST["modello_prodotto"]) && $_POST["modello_prodotto"] != null){
        if(strlen(strip_tags($_POST["modello_prodotto"]))>1 && strlen(strip_tags($_POST["modello_prodotto"]))<15) {
            $modello = strip_tags($_POST["modello_prodotto"]);
        } else {
            $validate=false;
            echo '<script language=javascript>alert("Modello non valido!")</script>';
            echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
        }
        
    }else{
        $_SESSION["message"] = "modello assente";
        echo '<script language=javascript>alert("Inserire il modello!")</script>';
        echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
        $validate = false;
    }
    
    if(isset($_POST["prezzo_acquisto_prodotto"]) && $_POST["prezzo_acquisto_prodotto"] != null){
        if(!preg_match("/^(\d*)-(\d*)[0-9]$/", $_POST["prezzo_acquisto_prodotto"])) {
            if(strlen(strip_tags($_POST["prezzo_acquisto_prodotto"]))>1 && strlen(strip_tags($_POST["prezzo_acquisto_prodotto"]))<=5) {
                
                $prezzoIN = strip_tags($_POST["prezzo_acquisto_prodotto"]);
            } else {
                $validate=false;
                echo '<script language=javascript>alert("Prezzo d acquisto non valido!")</script>';
                echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
            }
        } else {
            $validate=false;
            echo '<script language=javascript>alert("Inserisci il prezzo d acquisto!")</script>';
            echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
        }
        
    }else{
        $_SESSION["message"] = "prezzoA assente";
        echo $_SESSION["message"];
        $validate = false;
    }
    
    if(isset($_POST["prezzo_vendita_prodotto"]) && $_POST["prezzo_vendita_prodotto"] != null){
        if(!preg_match("/^(\d*)-(\d*)[0-9]$/", $_POST["prezzo_vendita_prodotto"])) {
            if(strlen(strip_tags($_POST["prezzo_acquisto_prodotto"]))>1 && strlen(strip_tags($_POST["prezzo_acquisto_prodotto"]))<=5) {
                if($_POST["prezzo_vendita_prodotto"]>$prezzoIN) {
                    $prezzoOUT = strip_tags($_POST["prezzo_vendita_prodotto"]);
                } else {
                    $validate=false;
                    echo '<script language=javascript>alert("Il prezzo d acquisto è superiore al prezzo di vendita!")</script>';
                    echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
                }
            } else {
                $validate=false;
                echo '<script language=javascript>alert("Prezzo di vendita non valido!")</script>';
                echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
            }
        } else {
            $validate=false;
            echo '<script language=javascript>alert("Prezzo di vendita non valido!")</script>';
            echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
        }
        
    }else{
        $_SESSION["message"] = "prezzoV assente";
        $validate=false;
        echo '<script language=javascript>alert("Prezzo di vendita non valido!")</script>';
        echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
        
    }
    
    if(isset($_POST["quantita_prodotto"]) && $_POST["quantita_prodotto"] != null){
        if(!preg_match("/^(\d*)-(\d*)[0-9]$/", $_POST["quantita_prodotto"])) {
            if(strlen($_POST["quantita_prodotto"])>=1 && strlen($_POST["quantita_prodotto"])<5){
                $quantita = strip_tags($_POST["quantita_prodotto"]);
            } else {
                $validate=false;
                echo '<script language=javascript>alert("Quantità non valida!")</script>';
                echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
            }
            
        } else {
            $validate=false;
            echo '<script language=javascript>alert("Quantità non valida!")</script>';
            echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
        }
        
    }else{
        $_SESSION["message"] = "quantita assente";
        echo $_SESSION["message"];
        $validate = false;
    }
    
    if(isset($_POST["select_categoria"]) && $_POST["select_categoria"] != null){
        if($_POST["select_categoria"]=="vuoto"){
            echo '<script language=javascript>alert("Inserire una categoria!")</script>';
            echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
            $validate=false;
            
        } else {
            $select_categoria = strip_tags($_POST["select_categoria"]);
        }
        
    }else{
        $_SESSION["message"] = "categoria assente";
        echo $_SESSION["message"];
        $validate = false;
    }
    
    if(isset($_POST["descrizione_prodotto"]) && $_POST["descrizione_prodotto"] != null){
        $descrizione = strip_tags($_POST["descrizione_prodotto"]);
    }else{
        $_SESSION["message"] = "descrizione assente";
        echo $_SESSION["message"];
        $validate = false;
    }
    
    
    
    
    
    
    
    $target_dir = "../assets/images/";
    $file=$_FILES["fileToUpload"]["name"];
    if($file!=null) {
        $target_file = $target_dir .$file;
        
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        // Check if image file is a actual image or fake image
        if(isset($_POST["submit"])) {
            $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
            if($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
            } else {
                $validate=false;
                echo "File is not an image.";
                $uploadOk = 0;
            }
        }
        // Check if file already exists
        if (file_exists($target_file)) {
            $validate=false;
            echo "Sorry, file already exists.";
            $uploadOk = 0;
        }
        // Check file size
        if ($_FILES["fileToUpload"]["size"] > 500000) {
            $validate=false;
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }
        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" ) {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
                $validate=false;
            }
            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                $validate=false;
                echo "Sorry, your file was not uploaded.";
                // if everything is ok, try to upload file
            }
    } else {
        $validate=false;
        echo '<script language=javascript>alert("immagine prodotto non inserita!")</script>';
        echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
    }
    
    if($validate == true){
        $prodotto = new Prodotto(null, $marca, $modello, $prezzoIN, $prezzoOUT, $quantita, $select_categoria, $descrizione,$target_file);
        
        
        $prodottoModel->insertProduct($prodotto);
        
        $_SESSION["message"] = "";
        echo '<script language=javascript>alert("Prodotto inserito con successo")</script>';
        echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
        
        
    }else {
        
        echo '<script language=javascript>alert("Prodotto non inserito, riprovare!")</script>';
        echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
    }
}
    ?>
    

