<?php
/**
 * Created by PhpStorm.
 * User: Vik10
 * Date: 06/03/2019
 * Time: 15:25
 */



ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once "../beans/User.php";
include_once "../model/UserModel.php";
include_once "../model/AdminModel.php";
session_start();


$userModel = new UserModel();
$adminModel = new AdminModel();

    $mail = strip_tags($_POST["mail_log"]);


    $email=trim($_POST["mail_log"]);
    $num_at = count(explode( '@', $email )) - 1;
    if($num_at != 1) {
        //formato email errato;
        echo '<script language=javascript>window.alert("Inserire una e-mail valida!")</script>';
        echo '<script language=javascript>document.location.href="../view/Login.html"</script>';
    }
    if(strpos($email,';') || strpos($email,',') || strpos($email,' ')) {
        //formato email errato;
        echo '<script language=javascript>window.alert("Inserire una e-mail valida!")</script>';
        echo '<script language=javascript>document.location.href="../view/Login.html"</script>';
    }
    if(!preg_match( '/^[\w\.\-]+@\w+[\w\.\-]*?\.\w{1,4}$/', $email)) {
        //formato email errato;
        echo '<script language=javascript>window.alert("Inserire una e-mail valida!")</script>';
        echo '<script language=javascript>document.location.href="../view/Login.html"</script>';
    }
    if($userModel->emailCheck($_POST["mail_log"])){
        $user = $userModel->getUserByMail($mail);
        
        $password = strip_tags($_POST["password"]);
        
        
        if ($userModel->passwordCheck($user, $password)) {
            
            
            if($userModel->powerAdminCheck($mail)) {
                
                $_SESSION["Adminlog"] = true;
                $_SESSION["codUtente"] = $user->getCodUtente();
                $_SESSION["log"] = true;
                $_SESSION["nomeUtente"] = $user->getNome();
                
                echo '<script language=javascript>document.location.href="../view/home_admin.php"</script>';
            } else {
                
                //Definisco le variabili di sessione dell'utente
                
                $_SESSION["log"] = true;
                $_SESSION["nomeUtente"] = $user->getNome();
                $_SESSION["codUtente"] = $user->getCodUtente();
                $user = $userModel->getUserByMail($mail);
                setcookie("login", $_SESSION["nomeUtente"], 0, "/");
                $nome= $_COOKIE['login'];
                //header('Location: ' . $_SERVER['HTTP_REFERER']);
                
                
                echo '<script language=javascript>document.location.href="../view/home.php"</script>';
                
            }
            
        } else {
            
            echo '<script language=javascript>window.alert("Password errata")</script>';
            echo '<script language=javascript>document.location.href="../view/Login.html"</script>';
        }
    
    
    
    
    
    
    } else {
        echo '<script language=javascript>window.alert("Email errata!")</script>';
        echo '<script language=javascript>document.location.href="../view/Login.html"</script>';
    }

