<?php
include_once "../beans/User.php";
include_once "../model/UserModel.php";

session_start();
$log=$_SESSION["log"];
if($log==$_SESSION["log"]) {
    $log=$_SESSION["log"];
    $codUt= $_SESSION["codUtente"];
}

$userModel = new UserModel();
$user=$userModel->getUserByCodUtente($codUt);

if(isset($_POST["mod_mail_reg"]) && $_POST["mod_mail_reg"]!=null) {
    if($_POST["mod_mail_reg"]!=$userModel->getMailByCodUtente($codUt)){
        $mod_mail_reg=trim($_POST["mod_mail_reg"]);
        $num_at = count(explode( '@', $mod_mail_reg )) - 1;
        if($num_at!=1) {
            //formato errato
            echo '<script language=javascript>alert("Inserire una e-mail valida1!")</script>';
            echo '<script language=javascript>document.location.href="../view/profiloAdmin.php"</script>';
            $validate = false;
        } else if (strpos($mod_mail_reg, ';') || strpos($mod_mail_reg, ',') || strpos($mod_mail_reg, ' ')) {
            //formato errato
            echo '<script language=javascript>alert("Inserire una e-mail valida1!")</script>';
            echo '<script language=javascript>document.location.href="../view/profiloAdmin.php"</script>';
        } else if(!preg_match( '/^[\w\.\-]+@\w+[\w\.\-]*?\.\w{1,4}$/', $mod_mail_reg)){
            //formato errato
            echo '<script language=javascript>alert("Inserire una e-mail valida1!")</script>';
            echo '<script language=javascript>document.location.href="../view/profiloAdmin.php"</script>';
        } else {
            if($mod_mail_reg!=$user->getMail()){
                if(isset($_POST["mod_password_reg"]) && $_POST["mod_password_reg"]!=null){
                    if(isset($_POST["mod_passwordControl_reg"]) && $_POST["mod_passwordControl_reg"]!=null){
                        $pass1=$_POST["mod_password_reg"];
                        $pass2=$_POST["mod_passwordControl_reg"];
                        if($pass1==$user->getPassword()){
                            if($userModel->passwordReg($pass1, $pass2)){
                                $userModel->updateMail($codUt, $mod_mail_reg);
                            } else {
                                //le password non coincidono
                                echo '<script language=javascript>alert("Le password non coincidono!")</script>';
                                echo '<script language=javascript>document.location.href="../view/profiloAdmin.php"</script>';
                            }
                        } else {
                            //password errata
                            echo '<script language=javascript>alert("Password errata!")</script>';
                            echo '<script language=javascript>document.location.href="../view/profiloAdmin.php"</script>';
                        }
                    } else {
                        //inserisci password di controllo
                        echo '<script language=javascript>alert("Inserire la password di controllo!")</script>';
                        echo '<script language=javascript>document.location.href="../view/profiloAdmin.php"</script>';
                    }
                } else{
                    //inserisci password
                    echo '<script language=javascript>alert("Inserire la password!")</script>';
                    echo '<script language=javascript>document.location.href="../view/profiloAdmin.php"</script>';
                }
                echo '<script language=javascript>alert("Email cambiata!")</script>';
                echo '<script language=javascript>document.location.href="../view/home_admin.php"</script>';
                
            }
        }
        
        }
        
            
    
}


//password
if(isset($_POST["mod_mail_reg"]) && $_POST["mod_mail_reg"] !=null){
    if($_POST["mod_mail_reg"]==$userModel->getMailByCodUtente($codUt)) {
        if(isset($_POST["mod_password_reg"]) && $_POST["mod_password_reg"]!=null) {
            if(isset($_POST["mod_passwordControl_reg"]) && $_POST["mod_passwordControl_reg"]!=null) {
                $pass1=$_POST["mod_password_reg"];
                $pass2=$_POST["mod_passwordControl_reg"];
                if($pass1!=$user->getPassword()) {
                    if($userModel->passwordReg($pass1, $pass2)) {
                        $userModel->updatePassword($codUt, $pass1);
                        echo '<script language=javascript>document.location.href="../view/home_admin.php"</script>';
                    } else {
                        echo '<script language=javascript>alert("La password non rispetta il formato richiesto!")</script>';
                        echo '<script language=javascript>document.location.href="../view/profiloAdmin.php"</script>';
                    }
                }
                
            } else {
                echo '<script language=javascript>alert("Inserire la password di controllo!")</script>';
                echo '<script language=javascript>document.location.href="../view/profiloAdmin.php"</script>';
            }
            
        } else {
            echo '<script language=javascript>alert("Inserisci la password!")</script>';
            echo '<script language=javascript>document.location.href="../view/profiloAdmin.php"</script>';
        }
        
    }
    
    
}