<?php
include_once "../beans/Prodotto.php";
include_once "../model/ProdottoModel.php";
session_start();

$validate = true;

$prodottoModel = new ProdottoModel();

if(isset($_POST["select_option"]) && $_POST["select_option"] != null){
    $select_option = strip_tags($_POST["select_option"]);

}else{
    $_SESSION["message"] = "codProdotto assente";
    echo $_SESSION["message"];
    $validate = false;
}

if(isset($_POST["prezzo_prodotto"]) && $_POST["prezzo_prodotto"] != null){
    $prezzo_prodotto = strip_tags($_POST["prezzo_prodotto"]);
}else{
    $_SESSION["message"] = "prezzo_prodotto assente";
    echo $_SESSION["message"];
    $validate = false;
}

if($validate == true){



    $prodottoModel->updatePrezzoOUT($select_option,$prezzo_prodotto);

    $_SESSION["message"] = "Prezzo prodotto aggiornato con successo";
    echo $_SESSION["message"];


}else {
    $_SESSION["message"] = $_SESSION["message"] . " - Prezzo prodotto non aggiornato";
    echo '<script language=javascript>alert("Prezzo prodotto non aggiornato, riprovare!")</script>';
}
