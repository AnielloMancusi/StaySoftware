<?php
/**
 * Created by PhpStorm.
 * User: Vik10
 * Date: 12/11/2018
 * Time: 09:55
 */

class Prodotto
{
    private $codProdotto;
    private $marca;
    private $modello;
    private $prezzo_IN;
    private $prezzo_OUT;
    private $quantita;
    private $categoria;
    private $descrizione;
    private $immagine;

    public function __construct($codProd, $marcaP, $modelloP, $prezzo_in, $prezzo_out, $quantitaP, $categoriaP, $descrizioneP, $immagineP){

        $this->codProdotto=$codProd;
        $this->marca=$marcaP;
        $this->modello=$modelloP;
        $this->prezzo_IN=$prezzo_in;
        $this->prezzo_OUT=$prezzo_out;
        $this->quantita=$quantitaP;
        $this->categoria=$categoriaP;
        $this->descrizione=$descrizioneP;
        $this->immagine=$immagineP;
    }

    /**
     * @return mixed
     */
    public function getCodProdotto()
    {
        return $this->codProdotto;
    }

    /**
     * @param mixed $codProdotto
     */
    public function setCodProdotto($codProdotto)
    {
        $this->codProdotto = $codProdotto;
    }

    /**
     * @return mixed
     */
    public function getMarca()
    {
        return $this->marca;
    }

    /**
     * @param mixed $marca
     */
    public function setMarca($marca)
    {
        $this->marca = $marca;
    }

    /**
     * @return mixed
     */
    public function getModello()
    {
        return $this->modello;
    }

    /**
     * @param mixed $modello
     */
    public function setModello($modello)
    {
        $this->modello = $modello;
    }

    /**
     * @return mixed
     */
    public function getPrezzoIN()
    {
        return $this->prezzo_IN;
    }

    /**
     * @param mixed $prezzo_IN
     */
    public function setPrezzoIN($prezzo_IN)
    {
        $this->prezzo_IN = $prezzo_IN;
    }

    /**
     * @return mixed
     */
    public function getPrezzoOUT()
    {
        return $this->prezzo_OUT;
    }

    /**
     * @param mixed $prezzo_OUT
     */
    public function setPrezzoOUT($prezzo_OUT)
    {
        $this->prezzo_OUT = $prezzo_OUT;
    }

    /**
     * @return mixed
     */
    public function getQuantita()
    {
        return $this->quantita;
    }

    /**
     * @param mixed $quantita
     */
    public function setQuantita($quantita)
    {
        $this->quantita = $quantita;
    }

    /**
     * @return mixed
     */
    public function getCategoria()
    {
        return $this->categoria;
    }

    /**
     * @param mixed $categoria
     */
    public function setCategoria($categoria)
    {
        $this->categoria = $categoria;
    }

    /**
     * @return mixed
     */
    public function getDescrizione()
    {
        return $this->descrizione;
    }

    /**
     * @param mixed $descrizione
     */
    public function setDescrizione($descrizione)
    {
        $this->descrizione = $descrizione;
    }
    
    /**
     * @return mixed
     */
    public function getImmagine()
    {
        return $this->immagine;
    }
    
    /**
     * @param mixed $descrizione
     */
    public function setImmagine($immagine)
    {
        $this->immagine = $immagine;
    }

}