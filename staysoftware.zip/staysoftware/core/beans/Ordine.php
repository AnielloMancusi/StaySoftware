<?php
/**
 * Created by PhpStorm.
 * User: Vik10
 * Date: 12/11/2018
 * Time: 10:41
 */

class Ordine
{
    private $idO;
    private $codUt;
    private $codP;
    private $stato;
    private $prezzo;
    private $data;
    private $quantita;
    private $via;
    private $provRes;
    private $comuneRes;
    private $cap;



    /**
     * @return mixed
     */
    public function getIdO()
    {
        return $this->idO;
    }

    /**
     * @return mixed
     */
    public function getCodUt()
    {
        return $this->codUt;
    }

    /**
     * @return mixed
     */
    public function getCodP()
    {
        return $this->codP;
    }

    /**
     * @return mixed
     */
    public function getStato()
    {
        return $this->stato;
    }

    /**
     * @return mixed
     */
    public function getPrezzo()
    {
        return $this->prezzo;
    }

    /**
     * @return mixed
     */
    public function getData()
    {
        return $this->data;
    }

    /**
     * @return mixed
     */
    public function getQuantita()
    {
        return $this->quantita;
    }

    /**
     * @return mixed
     */
    public function getVia()
    {
        return $this->via;
    }

    /**
     * @return mixed
     */
    public function getProvRes()
    {
        return $this->provRes;
    }

    /**
     * @return mixed
     */
    public function getComuneRes()
    {
        return $this->comuneRes;
    }

    /**
     * @return mixed
     */
    public function getCap()
    {
        return $this->cap;
    }

    /**
     * @param mixed $idO
     */
    public function setIdO($idO)
    {
        $this->idO = $idO;
    }

    /**
     * @param mixed $codUt
     */
    public function setCodUt($codUt)
    {
        $this->codUt = $codUt;
    }

    /**
     * @param mixed $codP
     */
    public function setCodP($codP)
    {
        $this->codP = $codP;
    }

    /**
     * @param mixed $stato
     */
    public function setStato($stato)
    {
        $this->stato = $stato;
    }

    /**
     * @param mixed $prezzo
     */
    public function setPrezzo($prezzo)
    {
        $this->prezzo = $prezzo;
    }

    /**
     * @param mixed $data
     */
    public function setData($data)
    {
        $this->data = $data;
    }

    /**
     * @param mixed $quantita
     */
    public function setQuantita($quantita)
    {
        $this->quantita = $quantita;
    }

    /**
     * @param mixed $via
     */
    public function setVia($via)
    {
        $this->via = $via;
    }

    /**
     * @param mixed $provRes
     */
    public function setProvRes($provRes)
    {
        $this->provRes = $provRes;
    }

    /**
     * @param mixed $comuneRes
     */
    public function setComuneRes($comuneRes)
    {
        $this->comuneRes = $comuneRes;
    }

    /**
     * @param mixed $cap
     */
    public function setCap($cap)
    {
        $this->cap = $cap;
    }

    public function __construct($idOrd, $codProdotto, $codUtente, $statoOrd, $prezzo, $data1, $quantita, $via, $provSped,
        $comSped, $capSped)
    {
        $this->idO = $idOrd;
        $this->codUt=$codUtente;
        $this->codP=$codProdotto;
        $this->stato=$statoOrd;
        $this->prezzo=$prezzo;
        $this->data=$data1;
        $this->quantita=$quantita;
        $this->via=$via;
        $this->provRes=$provSped;
        $this->comuneRes=$comSped;
        $this->cap=$capSped;
    }

    
}