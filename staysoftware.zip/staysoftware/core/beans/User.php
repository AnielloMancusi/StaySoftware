<?php
/**
 * Created by PhpStorm.
 * User: Vik10
 * Date: 11/11/2018
 * Time: 11:15
 */

class User
{
    private $codUtente;
    private $nome;
    private $cognome;
    private $codFiscale;
    private $dataNascita;
    private $provinciaNascita;
    private $comuneNascita;
    private $nazioneNascita;
    private $via;
    private $provinciaResidenza;
    private $comuneResidenza;
    private $cap;
    private $sesso;
    private $telefono1;
    private $telefono2;
    private $admin;
    private $mail;
    private $password;

    public function __construct($codUt, $name, $surname, $codFi, $dataN, $provinciaN, $comuneN, $nazioneN, $street, $provinciaR, $comuneR, $postalCode, $gender, $phone1, $phone2, $adminC,
                                $email, $pass)
    {
        $this->codUtente = $codUt;
        $this->nome = $name;
        $this->cognome = $surname;
        $this->codFiscale = $codFi;
        $this->dataNascita = $dataN;
        $this->provinciaNascita = $provinciaN;
        $this->comuneNascita = $comuneN;
        $this->nazioneNascita = $nazioneN;
        $this->via = $street;
        $this->provinciaResidenza = $provinciaR;
        $this->comuneResidenza = $comuneR;
        $this->cap = $postalCode;
        $this->sesso = $gender;
        $this->telefono1 = $phone1;
        $this->telefono2 = $phone2;
        $this->admin = $adminC;
        $this->mail = $email;
        $this->password = $pass;
    }

    /**
     * @return mixed
     */
    public function getCodUtente()
    {
        return $this->codUtente;
    }

    /**
     * @param mixed $codUtente
     */
    public function setCodUtente($codUtente)
    {
        $this->codUtente = $codUtente;
    }

    /**
     * @return mixed
     */
    public function getNome()
    {
        return $this->nome;
    }

    /**
     * @param mixed $nome
     */
    public function setNome($nome)
    {
        $this->nome = $nome;
    }

    /**
     * @return mixed
     */
    public function getCognome()
    {
        return $this->cognome;
    }

    /**
     * @param mixed $cognome
     */
    public function setCognome($cognome)
    {
        $this->cognome = $cognome;
    }

    /**
     * @return mixed
     */
    public function getCodFiscale()
    {
        return $this->codFiscale;
    }

    /**
     * @param mixed $codFiscale
     */
    public function setCodFiscale($codFiscale)
    {
        $this->codFiscale = $codFiscale;
    }

    /**
     * @return mixed
     */
    public function getDataNascita()
    {
        return $this->dataNascita;
    }

    /**
     * @param mixed $dataNascita
     */
    public function setDataNascita($dataNascita)
    {
        $this->dataNascita = $dataNascita;
    }

    /**
     * @return mixed
     */
    public function getProvinciaNascita()
    {
        return $this->provinciaNascita;
    }

    /**
     * @param mixed $provinciaNascita
     */
    public function setProvinciaNascita($provinciaNascita)
    {
        $this->provinciaNascita = $provinciaNascita;
    }

    /**
     * @return mixed
     */
    public function getComuneNascita()
    {
        return $this->comuneNascita;
    }

    /**
     * @param mixed $comuneNascita
     */
    public function setComuneNascita($comuneNascita)
    {
        $this->comuneNascita = $comuneNascita;
    }

    /**
     * @return mixed
     */
    public function getNazioneNascita()
    {
        return $this->nazioneNascita;
    }

    /**
     * @param mixed $nazioneNascita
     */
    public function setNazioneNascita($nazioneNascita)
    {
        $this->nazioneNascita = $nazioneNascita;
    }

    /**
     * @return mixed
     */
    public function getVia()
    {
        return $this->via;
    }

    /**
     * @param mixed $via
     */
    public function setVia($via)
    {
        $this->via = $via;
    }

    /**
     * @return mixed
     */
    public function getProvinciaResidenza()
    {
        return $this->provinciaResidenza;
    }

    /**
     * @param mixed $provinciaResidenza
     */
    public function setProvinciaResidenza($provinciaResidenza)
    {
        $this->provinciaResidenza = $provinciaResidenza;
    }

    /**
     * @return mixed
     */
    public function getComuneResidenza()
    {
        return $this->comuneResidenza;
    }

    /**
     * @param mixed $comuneResidenza
     */
    public function setComuneResidenza($comuneResidenza)
    {
        $this->comuneResidenza = $comuneResidenza;
    }

    /**
     * @return mixed
     */
    public function getCap()
    {
        return $this->cap;
    }

    /**
     * @param mixed $cap
     */
    public function setCap($cap)
    {
        $this->cap = $cap;
    }

    /**
     * @return mixed
     */
    public function getSesso()
    {
        return $this->sesso;
    }

    /**
     * @param mixed $sesso
     */
    public function setSesso($sesso)
    {
        $this->sesso = $sesso;
    }

    /**
     * @return mixed
     */
    public function getTelefono1()
    {
        return $this->telefono1;
    }

    /**
     * @param mixed $telefono1
     */
    public function setTelefono1($telefono1)
    {
        $this->telefono1 = $telefono1;
    }

    /**
     * @return mixed
     */
    public function getTelefono2()
    {
        return $this->telefono2;
    }

    /**
     * @param mixed $telefono2
     */
    public function setTelefono2($telefono2)
    {
        $this->telefono2 = $telefono2;
    }

    /**
     * @return mixed
     */
    public function getAdmin()
    {
        return $this->admin;
    }

    /**
     * @param mixed $admin
     */
    public function setAdmin($admin)
    {
        $this->admin = $admin;
    }

    /**
     * @return mixed
     */
    public function getMail()
    {
        return $this->mail;
    }

    /**
     * @param mixed $mail
     */
    public function setMail($mail)
    {
        $this->mail = $mail;
    }

    /**
     * @return mixed
     */

    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param mixed $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }
}