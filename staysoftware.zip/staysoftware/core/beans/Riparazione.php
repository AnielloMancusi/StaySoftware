<?php
/**
 * Created by PhpStorm.
 * User: Vik10
 * Date: 12/11/2018
 * Time: 10:32
 */

class Riparazione
{
    private $idR;
    private $descrizione;
    private $prezzo;
    private $stato;
    private $cliente;

    public function __construct($idRip, $descr, $costo, $statoR, $user){
        $this->idR=$idRip;
        $this->descrizione=$descr;
        $this->prezzo=$costo;
        $this->stato=$statoR;
        $this->cliente=$user;
    }

    /**
     * @return mixed
     */
    public function getIdR()
    {
        return $this->idR;
    }

    /**
     * @param mixed $idR
     */
    public function setIdR($idR)
    {
        $this->idR = $idR;
    }

    /**
     * @return mixed
     */
    public function getDescrizione()
    {
        return $this->descrizione;
    }

    /**
     * @param mixed $descrizione
     */
    public function setDescrizione($descrizione)
    {
        $this->descrizione = $descrizione;
    }

    /**
     * @return mixed
     */
    public function getPrezzo()
    {
        return $this->prezzo;
    }

    /**
     * @param mixed $prezzo
     */
    public function setPrezzo($prezzo)
    {
        $this->prezzo = $prezzo;
    }

    /**
     * @return mixed
     */
    public function getStato()
    {
        return $this->stato;
    }

    /**
     * @param mixed $stato
     */
    public function setStato($stato)
    {
        $this->stato = $stato;
    }

    /**
     * @return mixed
     */
    public function getCliente()
    {
        return $this->cliente;
    }

    /**
     * @param mixed $cliente
     */
    public function setCliente($cliente)
    {
        $this->cliente = $cliente;
    }



}

