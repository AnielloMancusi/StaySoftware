<?php
/**
 * Created by PhpStorm.
 * User: Vik10
 * Date: 11/11/2018
 * Time: 11:14
 */

class Admin
{
    private $codAdmin;
    private $email;
    private $password;

    public function __construt($codiceAd, $email, $pass){
        $this->codAdmin = $codiceAd;
        $this->email = $email;
        $this->password = $pass;
    }

    /**
     * @return mixed
     */
    public function getCodAdmin()
    {
        return $this->codAdmin;
    }

    /**
     * @param mixed $codAdmin
     */
    public function setCodAdmin($codAdmin)
    {
        $this->codAdmin = $codAdmin;
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param mixed $email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     * @return mixed
     */
    public function getPassword()
    {
       return $this->password;
    }

    /**
     * @param mixed $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }


}
