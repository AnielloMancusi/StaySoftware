<?php
/**
 * Created by PhpStorm.
 * User: Vik10
 * Date: 13/11/2018
 * Time: 12:34
 */

include_once "../beans/Ordine.php";
include_once "../../core/model/Connector.php";

class OrdineModel
{


    public function __construct()
    {
    }

    public function insertOrder($ordine)
    {
        
        $insert_query = "INSERT INTO ordine (idO, idP, codUt, stato, prezzo, data, quantita, via, provinciaSped, 
        comuneSped, capSped) VALUES (NULL, '%d', '%d', '%s', '%d', '%s', '%d', '%s', '%s', '%s', '%s')";
        $query = sprintf($insert_query, $ordine->getCodP(), $ordine->getCodUt(), $ordine->getStato(), $ordine->getPrezzo(), $ordine->getData(), $ordine->getQuantita(), $ordine->getVia(), $ordine->getProvRes(), $ordine->getComuneRes(), $ordine->getCap() );

        if (!mysqli_query(Connector::getConnector(), $query)) {
            echo("Error".mysqli_error(Connector::getConnector())."\n");
        }
    }

    public function updateStato($ordine, $stato, $codUt, $codO) {

        $insert_query = "INSERT INTO ordine (stato) VALUE ('%s')
                          SELECT stato
                          FROM $ordine
                          WHERE codUt='%s' && codO='%s'";
        $query = sprintf($insert_query, $codO, $stato, $codUt);
        $result = mysqli_query(Connector::getConnector(), $query);
        if($result){
            return true;
        }
        return false;
    }

    public function updateData($ordine, $data, $codUt, $codO) {

        $insert_query = "INSERT INTO ordine (data) VALUE ('%s')
                          SELECT stato
                          FROM $ordine
                          WHERE codUt='%s' && codO='%s'";
        $query = sprintf($insert_query, $codO, $data, $codUt);
        $result = mysqli_query(Connector::getConnector(), $query);
        if($result){
            return true;
        }
        return false;
    }

    public function annullaOrdine($ordine, $stato, $codUt, $codO) {

        $insert_query = "DELETE FROM  ordine                           
                         WHERE codUt='%s' && codO='%s' && stato='in elaborazione'";
        $query = sprintf($insert_query, $codO, $stato, $codUt);
        $result = mysqli_query(Connector::getConnector(), $query);
        if($result){
            return true;
        }
        return $result;
    }

    public function visualizzaOrdiniBycodUt($codUt) {
        $insert_query = "SELECT *
                         WHERE codUt='%s' 
                         FROM ordine";
        $query = sprintf($insert_query, $codUt);
        $result = mysqli_query(Connector::getConnector(), $query);
        $ordini=array();
        if($result){
            while($obj = $result->fetch_assoc()){
                $ordine =new Ordine($obj['idO'], $obj['idP'], $obj['codUt'], $obj['stato'], $obj['prezzo'], $obj['data'], $obj['quantita'], $obj['via'], $obj['provinciaSped'],
                    $obj['comuneSped'], $obj['capSped']);
                $ordini[]=$ordine;
            }
        }

        return $ordini;
        if($result) {
            return true;
        } else {
            return false;
        }
    }
    


}