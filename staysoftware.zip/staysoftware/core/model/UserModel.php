<?php
/**
 * Created by PhpStorm.
 * User: Vik10
 * Date: 13/11/2018
 * Time: 09:17
 */


include_once "../../core/beans/User.php";
include_once "../../core/model/Connector.php";
include_once "../../core/control/CodiceFiscaleControl.php";

class UserModel{

    public function __construct() {
    }

    public function insertUser($user){

        $insert_query = "INSERT INTO utenti(codUtente, nome, cognome, codFiscale, dataNascita, provinciaNascita, comuneNascita, nazioneNascita, via, 
                        provinciaResidenza, comuneResidenza, cap, sesso, telefono1, telefono2, admin, mail, password) VALUES (NULL , '%s', '%s', 
                        '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')";
        $query = sprintf($insert_query, $user->getNome(), $user->getCognome(), $user->getCodFiscale(), $user->getDataNascita(),
            $user->getProvinciaNascita(), $user->getComuneNascita(), $user->getNazioneNascita(),
            $user->getVia(), $user->getProvinciaResidenza(), $user->getComuneResidenza(), $user->getCap(), $user->getSesso(), $user->getTelefono1(), $user->getTelefono2(),
            $user->getAdmin(), $user->getMail(), $user->getPassword());
    
        if (!mysqli_query(Connector::getConnector(), $query)) {
            echo("Error".mysqli_error(Connector::getConnector())."\n");
        }
    }

    public function getAllUser(){
        $select_query = "SELECT * FROM utenti";
        $result = mysqli_query(Connector::getConnector(), $select_query);
        $users = array();
        if($result){
            while($obj = $result->fetch_assoc()){
                $user = new User($obj['codUtente'], $obj['nome'], $obj['cognome'], $obj['codFiscale'], $obj['dataNascita'],
                    $obj['provinciaNascita'], $obj['comuneNascita'], $obj['nazioneNascita'], $obj['via'],
                    $obj['provinciaResidenza'], $obj['comuneResidenza'], $obj['cap'], $obj['sesso'], $obj['telefono1'],
                    $obj['telefono2'], $obj['admin'], $obj['mail'], $obj['password']);
                $users[] = $user;
            }
        }
        return $users;
    }

    public function getUserByCodUtente($codUtente){
        $select_query = "SELECT * FROM utenti WHERE codUtente = '%s'";
        $query = sprintf($select_query, $codUtente);
        $result = mysqli_query(Connector::getConnector(), $query);
        $user = null;
        if ($result){
            while ($obj = $result->fetch_assoc()){
                $user =  new User($obj['codUtente'], $obj['nome'], $obj['cognome'], $obj['codFiscale'], $obj['dataNascita'],
                    $obj['provinciaNascita'], $obj['comuneNascita'], $obj['nazioneNascita'], $obj['via'],
                    $obj['provinciaResidenza'], $obj['comuneResidenza'], $obj['cap'], $obj['sesso'], $obj['telefono1'],
                    $obj['telefono2'], $obj['admin'], $obj['mail'], $obj['password']);
            }
        }
       
       
        return $user;
    }
    
    public function getMailByCodUtente($codUtente){
        $select_query = "SELECT mail FROM utenti WHERE codUtente = '%s'";
        $query=sprintf($select_query, $codUtente);
        $result = mysqli_query(Connector::getConnector(), $query);
        $mail=null;
        if($result!=null) {
            $row = mysqli_fetch_array($result);          
            $mail=$row[0];     
        }
        return $mail;
        
    }
    

    public function getUserByMail($mail){
        $select_query = "SELECT * FROM utenti WHERE mail = '%s'";
        $query = sprintf($select_query, $mail);
        $result = mysqli_query(Connector::getConnector(), $query);
        $user = null;
        if ($result){
            while ($obj = $result->fetch_assoc()){
                $user =  new User($obj['codUtente'], $obj['nome'], $obj['cognome'], $obj['codFiscale'], $obj['dataNascita'],
                    $obj['provinciaNascita'], $obj['comuneNascita'], $obj['nazioneNascita'], $obj['via'],
                    $obj['provinciaResidenza'], $obj['comuneResidenza'], $obj['cap'], $obj['sesso'], $obj['telefono1'],
                    $obj['telefono2'], $obj['admin'], $obj['mail'], $obj['password']);
            }
        }
        return $user;
    }

    public function getAllAdmin() {
             $select_query = "SELECT * FROM utenti WHERE admin='si'";
        $result = mysqli_query(Connector::getConnector(), $select_query);
        $users = array();
        if($result){
            while($obj = $result->fetch_assoc()){
                $user = new User($obj['codUtente'], $obj['nome'], $obj['cognome'], $obj['codFiscale'], $obj['dataNascita'],
                    $obj['provinciaNascita'], $obj['comuneNascita'], $obj['nazioneNascita'], $obj['via'],
                    $obj['provinciaResidenza'], $obj['comuneResidenza'], $obj['cap'], $obj['sesso'], $obj['telefono1'],
                    $obj['telefono2'], $obj['admin'], $obj['mail'], $obj['password']);
                $users[] = $user;
            }
        }
        return $users;
    }

public function powerAdminCheck($mail){
  $users = $this->getAllAdmin();
  for($i=0;$i<count($users);$i++){
      if(strcmp($users[$i]->getMail(), $mail)==0) {
          return true;
      }
  }
  return false;
}





    public function getUserByName($nome){
        $select_query = "SELECT * FROM utenti WHERE nome = '%s'";
        $query = sprintf($select_query, $nome);
        $result = mysqli_query(Connector::getConnector(), $query);
        $users = array();
        if($result){
            while ($obj = $result->fetch_assoc()){
                $user = new User($obj['codUtente'], $obj['nome'], $obj['cognome'], $obj['codFiscale'], $obj['dataNascita'],
                    $obj['provinciaNascita'], $obj['comuneNascita'], $obj['nazioneNascita'], $obj['via'],
                    $obj['provinciaResidenza'], $obj['comuneResidenza'], $obj['cap'], $obj['sesso'], $obj['telefono1'],
                    $obj['telefono2'], $obj['admin'], $obj['mail'],  $obj['password']);
                $users[] = $user;
            }
        }
        return $users;
    }

    public function getUserBySurname($cognome){
        $select_query = "SELECT * FROM utenti WHERE cognome = '%s'";
        $query = sprintf($select_query, $cognome);
        $result = mysqli_query(Connector::getConnector(), $query);
        $users = array();
        if($result){
            while ($obj = $result->fetch_assoc()){
                $user = new User($obj['codUtente'], $obj['nome'], $obj['cognome'], $obj['codFiscale'], $obj['dataNascita'],
                    $obj['provinciaNascita'], $obj['comuneNascita'], $obj['nazioneNascita'], $obj['via'],
                    $obj['provinciaResidenza'], $obj['comuneResidenza'], $obj['cap'], $obj['sesso'], $obj['telefono1'],
                    $obj['telefono2'], $obj['admin'], $obj['mail'], $obj['password']);
                $users[] = $user;
            }
        }
        return $users;
    }

    public function getUserByCodFiscale($codFiscale){
        $select_query = "SELECT * FROM utenti WHERE codFiscale = '%s'";
        $query = sprintf($select_query, $codFiscale);
        $result = mysqli_query(Connector::getConnector(), $query);
        $user = null;
        if($result){
            while ($obj = $result->fetch_assoc()){
                $user = new User($obj['codUtente'], $obj['nome'], $obj['cognome'], $obj['codFiscale'], $obj['dataNascita'],
                    $obj['provinciaNascita'], $obj['comuneNascita'], $obj['nazioneNascita'], $obj['via'],
                    $obj['provinciaResidenza'], $obj['comuneResidenza'], $obj['cap'], $obj['sesso'], $obj['telefono1'],
                    $obj['telefono2'], $obj['admin'], $obj['mail'],  $obj['password']);
            }
        }
        return $user;
    }

    public function getUserByProvincaResidenza($provinciaResidenza){
        $select_query = "SELECT * FROM utenti WHERE provinciaResidenza = '%s'";
        $query = sprintf($select_query, $provinciaResidenza);
        $result = mysqli_query(Connector::getConnector(), $query);
        $users = array();
        if($result){
            while ($obj = $result->fetch_assoc()){
                $user = new User($obj['codUtente'], $obj['nome'], $obj['cognome'], $obj['codFiscale'], $obj['dataNascita'],
                    $obj['provinciaNascita'], $obj['comuneNascita'], $obj['nazioneNascita'], $obj['via'],
                    $obj['provinciaResidenza'], $obj['comuneResidenza'], $obj['cap'], $obj['sesso'], $obj['telefono1'],
                    $obj['telefono2'], $obj['admin'], $obj['mail'], $obj['password']);
                $users[] = $user;
            }
        }
        return $users;
    }

    public function getUserByComuneResidenza($comuneResidenza){
        $select_query = "SELECT * FROM utenti WHERE comuneResidenza = '%s'";
        $query = sprintf($select_query, $comuneResidenza);
        $result = mysqli_query(Connector::getConnector(), $query);
        $users = array();
        if($result){
            while ($obj = $result->fetch_assoc()){
                $user = new User($obj['codUtente'], $obj['nome'], $obj['cognome'], $obj['codFiscale'], $obj['dataNascita'],
                    $obj['provinciaNascita'], $obj['comuneNascita'], $obj['nazioneNascita'], $obj['via'],
                    $obj['provinciaResidenza'], $obj['comuneResidenza'], $obj['cap'], $obj['sesso'], $obj['telefono1'],
                    $obj['telefono2'], $obj['admin'], $obj['mail'], $obj['password']);
                $users[] = $user;
            }
        }
        return $users;
    }
    

    


    public function emailCheck($mail){
        $users = $this->getAllUser();
        for($i=0;$i<count($users);$i++){
            if(strcmp($users[$i]->getMail(), $mail)==0) {
                return true;
            }
        }
        return false;
    }



    public function passwordCheck($user, $password){
        
        $pass = $user->getPassword();
        if (strcmp($pass, $password) == 0){
            return true;
        }
        return false;
    }

    public function codFiscaleCheck($codFiscale){
        $users= $this->getAllUser();
        for($i=0;$i<count($users);$i++){
            if(strcmp($users[$i]->getCodFiscale(), $codFiscale) == 0){
                return true;
            }
        }
        return false;
    }



    public function updateResidenza($codUtente, $via, $provinciaResidenza, $comuneResidenza, $cap){
        $update_query = "UPDATE utenti SET via = '%s', provinciaResidenza = '%s', comuneResidenza = '%s', cap = '%s' WHERE
                        codUtente = '%s' ";
        $query = sprintf($update_query, $via, $provinciaResidenza, $comuneResidenza, $cap, $codUtente);
        $result = mysqli_query(Connector::getConnector(), $query);
        if($result){
            return true;
        }
        return false;
    }

    public function updateMail($codUtente, $mail){
        if(!$this->emailCheck($mail)){
            $update_query = "UPDATE utenti SET mail = '%s' WHERE codUtente = '%s'";
            $query = sprintf($update_query,$mail,$codUtente);
            $result = mysqli_query(Connector::getConnector(), $query);
            if($result){
                return true;
            }
            return false;
        }
        return false;
    }

    public function updatePassword($codUtente, $password){
        $update_query = "UPDATE utenti SET password = '%s' WHERE codUtente = '%s'";
        $query = sprintf($update_query, $password, $codUtente);
        $result = mysqli_query(Connector::getConnector(), $query);
        if($result){
            return true;
        }
        return false;
    }
    
    public function updateNome($codUtente, $nome){
        if(UserModel::checkNome($nome)) {
            $update_query = "UPDATE utenti SET nome = '%s' WHERE codUtente = '%s'";
            $query = sprintf($update_query, $nome, $codUtente);
            $result = mysqli_query(Connector::getConnector(), $query);
            if($result){
                return true;
            }
            return false;
        } else {
            return false;
        }
        
    }
    
    public function updateCognome($codUtente, $cognome){
        if(UserModel::checkNome($cognome)){
            $update_query = "UPDATE utenti SET cognome = '%s' WHERE codUtente = '%s'";
            $query = sprintf($update_query, $cognome, $codUtente);
            $result = mysqli_query(Connector::getConnector(), $query);
            if($result){
                return true;
            }
            return false;
        }else {
            return false;
        }
        
    }
    
    public function updateDataN($codUtente, $data){
        $update_query = "UPDATE utenti SET datanascita = '%s' WHERE codUtente = '%s'";
        $query = sprintf($update_query, $data, $codUtente);
        $result = mysqli_query(Connector::getConnector(), $query);
        if($result){
            return true;
        }
        return false;
    }
    
    public function updateProvN($codUtente, $provN) {
        $update_query = "UPDATE utenti SET provinciaNascita = '%s' WHERE codUtente = '%s";
        $query = sprintf($update_query, $provN, $codUtente);
        $result = mysqli_query(Connector::getConnector(), $query);
        if($result) {
            return true;
        }
        return false;
    }
    
    public function updateComuneN($codUtente, $comuneN) {
        $update_query = "UPDATE utenti SET comuneNascita = '%s' WHERE codUtente = '%s";
        $query = sprintf($update_query, $comuneN, $codUtente);
        $result = mysqli_query(Connector::getConnector(), $query);
        if($result) {
            return true;
        }
        return false;
    }
    
    public function updateNazionalità($codUtente, $nazionalita) {
        $update_query = "UPDATE utenti SET nazioneNascita = '%s' WHERE codUtente = '%s'";
        $query = sprintf($update_query, $nazionalita, $codUtente);
        $result= mysqli_query(Connector::getConnector(), $query);
        if($result){
            return true;
        }
        return false;
    }
    
    public function updateIndirizzo($codUtente, $indirizzo){
        $update_query = "UPDATE utenti SET via = '%s' WHERE codUtente = '%s'";
        $query = sprintf($update_query, $indirizzo, $codUtente);
        $result= mysqli_query(Connector::getConnector(), $query);
        if(result){
            return true;
        }
        return false;
    }
    
    public function updateProvR($codUtente, $provR) {
        $update_query = "UPDATE utenti SET provinciaResidenza = '%s' WHERE codUtente = '%s";
        $query = sprintf($update_query, $provR, $codUtente);
        $result = mysqli_query(Connector::getConnector(), $query);
        if($result) {
            return true;
        }
        return false;
    }
    
    public function updateComuneR($codUtente, $comuneR) {
        $update_query = "UPDATE utenti SET comuneResidenza = '%s' WHERE codUtente = '%s";
        $query = sprintf($update_query, $comuneR, $codUtente);
        $result = mysqli_query(Connector::getConnector(), $query);
        if($result) {
            return true;
        }
        return false;
    }
    
    public function updateCAP($codUtente, $cap) {
        $update_query = "UPDATE utenti SET cap= '%s' WHERE codUtente = '%s";
        $query = sprintf($update_query, $cap, $codUtente);
        $result = mysqli_query(Connector::getConnector(), $query);
        if($result) {
            return true;
        }
        return false;
    }
    
    public function updateSesso($codUtente, $sesso){
        $update_query = "UPDATE utenti SET sesso = '%s' WHERE codUtente = '%s'";
        $query = sprintf($update_query, $sesso, $codUtente);
        $result = mysqli_query(Connector::getConnector(), $query);
        if($result){
            return true;
        }
        return false;
    }
    
    public function updateTel1($codUtente, $tel1){
        $update_query = "UPDATE utenti SET telefono1 = '%s' WHERE codUtente = '%s'";
        $query = sprintf($update_query, $tel1, $codUtente);
        $result = mysqli_query(Connector::getConnector(), $query);
        if($result){
            return true;
        }
        return false;
    }
    
    public function updateTel2($codUtente, $tel2){
        $update_query = "UPDATE utenti SET telefono2 = '%s' WHERE codUtente = '%s'";
        $query = sprintf($update_query, $tel2, $codUtente);
        $result = mysqli_query(Connector::getConnector(), $query);
        if($result){
            return true;
        }
        return false;
    }
    

    
    
    public function updateCf($codUtente, $codF){
       
        if(ControllaCF($codF)){
            
            $update_query = "UPDATE utenti SET codFiscale = '%s' WHERE codUtente = '%s'";
            $query = sprintf($update_query, $codF, $codUtente);
            $result = mysqli_query(Connector::getConnector(), $query);
          
            
            if($result){
                return true;
              
            }
            return false;
        }
        else {
          
            return false;
        }
    }
    

    
    public function checkNome($nomeUt) {
        //controlla nome
        if(isset($nomeUt) && $nomeUt != null){
            if(strlen($nomeUt)< 3 || strlen($nomeUt) >30){
                echo '<script language=javascript>alert("Nome non valido")</script>';
                return false;
            }
            
        } else {
            echo '<script language=javascript>alert("Inserisci un nome")</script>';
            return false;
        }
        return true;
    }
    
    public function checkCognome($cognomeUt){
        if(isset($cognomeUt) && $cognomeUt != null){
            
            if(strlen($cognomeUt)< 3 || strlen($cognomeUt) >30){
                echo '<script language=javascript>alert("Cognome non valido")</script>';
                return false;
            }
            
        } else {
            echo '<script language=javascript>alert("Inserisci un Cognome")</script>';
            return false;
        }
        return true;
    }
    
    public function checkCF($cfUt) {
        if(isset($cfUt) && $cfUt != null){
            
            if(ControllaCF($cfUt)==false){
                //cf non corretto
                return false;
                echo '<script language=javascript>alert("Codice Fiscale errato!")</script>';
                
            }else {
                return true;
            }
            
            
        }
    }
    
    public function mailReg($mail) {
        if(isset($mail) && $mail!= null){
            
            $email=trim($mail);
            $num_at = count(explode( '@', $email )) - 1;
            if($num_at != 1) {
                //formato email errato;
                echo '<script language=javascript>alert("Inserire una e-mail valida1!")</script>';
                return false;
            }
            if(strpos($email,';') || strpos($email,',') || strpos($email,' ')) {
                //formato email errato;
                echo '<script language=javascript>alert("Inserire una e-mail valida!2")</script>';
                return false;
            }
            if(!preg_match( '/^[\w\.\-]+@\w+[\w\.\-]*?\.\w{1,4}$/', $email)) {
                //formato email errato;
                echo '<script language=javascript>alert("Inserire una e-mail valida!3")</script>';
                return false;
            }
            if(emailCheck($_POST["mail_reg"])){
                echo '<script language=javascript>alert("E-mail già presente!")</script>';
                return false;
            }
            
            
        } else {
            //inserisci una mail
            echo '<script language=javascript>alert("Inserire una e-mail valida!4")</script>';
            return false;
        }
        
        return true;
        
    }
    
    public function passwordReg($password, $passControl) {
        if(isset($password) && $password != null){
            if(isset($passControl) && $passControl != null) {
                
                    //CONTROLLA PREG_MATCH per i simboli
                    if(strlen($password)>7 && strlen($password)<20) {
                        
                        if(preg_match('/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%]/', $password)) {
                            if($password==$passControl) {
                                echo '<script language=javascript>alert("Password inserita!")</script>';
                                return true;
                            } else {
                                echo '<script language=javascript>alert(""Le password non corrispondono!!")</script>';
                                return false;
                            }
                            
                        } else {
                            echo '<script language=javascript>alert("La password deve contenere lettere e numeri!")</script>';
                            return false;
                            
                        
                        }
                } else {
                    echo '<script language=javascript>alert("La password deve contenere almeno 8 caratteri!!")</script>';
                    return false;
                }
                
            }
        } else{
            echo '<script language=javascript>alert("Inserisci una password!")</script>';
            return false;

        }
    }
    

}