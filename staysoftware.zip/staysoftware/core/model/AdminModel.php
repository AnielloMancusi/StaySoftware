<?php
/**
 * Created by PhpStorm.
 * User: Vik10
 * Date: 12/11/2018
 * Time: 11:06
 */


include_once "../beans/User.php";
include_once "Connector.php";



class AdminModel
{


    public function __construct()
    {
    }


    public function getAllAdmin()
    {
        $select_query = "SELECT * FROM utenti WHERE admin = 'si'";
        $result = mysqli_query(Connector::getConnector(), $select_query);
        $allAdmins = array();
        if ($result) {
            while ($obj = $result->fetch_assoc()) {
                $admin = new User($obj['codUtente'], $obj['nome'], $obj['cognome'], $obj['codFiscale'], $obj['dataNascita'],
                    $obj['provinciaNascita'], $obj['comuneNascita'], $obj['nazioneNascita'], $obj['via'],
                    $obj['provinciaResidenza'], $obj['comuneResidenza'], $obj['cap'], $obj['sesso'], $obj['telefono1'],
                    $obj['telefono2'], $obj['mail'], $obj['password']);
                $allAdmins[] = $admin;
            }
        }
        return $allAdmins;
    }


    public function getAdminByMail($mail)
    {
        echo $mail;
        echo ' &  ';

        $select_query = "SELECT * FROM admin WHERE email = '%s' && admin = 'si'";
        $query = sprintf($select_query, $mail);
        $result = mysqli_query(Connector::getConnector(), $query);
        $admin = null;
        if ($result) {
            while ($obj = $result->fetch_assoc()) {
                $admin = new Admin($obj['codAdmin'], $obj['email'], $obj['password']);

            }
        }


        return $admin;
    }


    public function emailCheck($mail){
        $users = $this->getAllAdmin();
        for($i=0;$i<count($users);$i++){
            if(strcmp($users[$i]->getMail(), $mail)==0) {
                return true;
            }
        }
        return false;
    }


    public function passwordCheck($user, $password){

        $pass = $user->getPassword();

        if (strcmp($pass, $password) == 0){
            return true;
        }
        return false;
    }
}