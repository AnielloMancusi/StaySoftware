<?php
/**
 * Created by PhpStorm.
 * User: Vik10
 * Date: 13/11/2018
 * Time: 10:56
 */
include_once "../beans/Prodotto.php";
include_once "Connector.php";
class ProdottoModel{

    public function __construct() {
    }

    public function insertProduct($prodotto){

        $insert_query = "INSERT INTO prodotto(codProdotto, marca, modello, prezzo_IN, prezzo_OUT, quantita, categoria, descrizione, immagine) VALUES (NULL , '%s', '%s', 
                        '%d', '%d', '%d', '%s', '%s','%s')";
        $query = sprintf($insert_query, $prodotto->getMarca(), $prodotto->getModello(), $prodotto->getPrezzoIN(), $prodotto->getPrezzoOut(), $prodotto->getQuantita(),
            $prodotto->getCategoria(), $prodotto->getDescrizione(), $prodotto->getImmagine());

        if (!mysqli_query(Connector::getConnector(), $query)) {
            echo("Error".mysqli_error(Connector::getConnector())."\n");
        }
    }

    public function getAllProduct(){
        $select_query = "SELECT * FROM prodotto";
        $result = mysqli_query(Connector::getConnector(), $select_query);
        $products = array();
        if($result){
            while($obj = $result->fetch_assoc()){
                $prodotto = new Prodotto($obj['codProdotto'], $obj['marca'], $obj['modello'], $obj['prezzo_IN'], $obj['prezzo_OUT'],
                    $obj['quantita'], $obj['categoria'], $obj['descrizione'], $obj['immagine']);
                $products[] = $prodotto;
            }
        }
        return $products;
    }

    public function getProductByCod($codProdotto){
        $select_query = "SELECT * FROM prodotto WHERE codProdotto = '%s'";
        $query = sprintf($select_query, $codProdotto);
        $result = mysqli_query(Connector::getConnector(), $query);
        $prodotto = null;
        if ($result){
            while ($obj = $result->fetch_assoc()){
                $prodotto=  new Prodotto($obj['codProdotto'], $obj['marca'], $obj['modello'], $obj['prezzo_IN'], $obj['prezzo_OUT'],
                    $obj['quantita'], $obj['categoria'], $obj['descrizione'], $obj['immagine']);
            }
        }
        return $prodotto;
    }
    
   



    public function updatePrezzoOUT($codProdotto, $prezzoOUT){
        if($codProdotto!=null) {
            if($prezzoOUT!=null) {
                $update_query = "UPDATE prodotto SET prezzo_OUT= '%d' WHERE codProdotto = '%s' ";
                $query = sprintf($update_query, $prezzoOUT, $codProdotto);
                $result = mysqli_query(Connector::getConnector(), $query);
                if($result){
                    return true;
                }
                return false;
            } else {
                return false;
            }
        } else {
            return false;
        }

    }

    public function updateQuantita($codProdotto, $quantita){
        if($codProdotto!=null) {
            if($quantita!=null && is_string($quantita==false)){
                $update_query = "UPDATE prodotto SET quantita= '%d' WHERE codProdotto = '%s' ";
                $query = sprintf($update_query, $quantita, $codProdotto);
                $result = mysqli_query(Connector::getConnector(), $query);
                if($result){
                    return true;
                }
                return false;
            } else {
                return false;
            }
        } else {
            return false;
        }

    }

    public function removeProduct($codProdotto){

        if($codProdotto!=null) {
            $delete_query = "DELETE FROM prodotto WHERE codProdotto='%s'";
            $query = sprintf($delete_query, $codProdotto);
            $result = mysqli_query(Connector::getConnector(), $query);
            if($result) {
                return true;
            }
            return false;
        } else {
            return false;
        }



    }
    public function visualProdotti($categoria){
        $visual_query = "SELECT * FROM prodotto WHERE categoria='$categoria'";
        $query = sprintf($visual_query, $categoria);
        $result = mysqli_query(Connector::getConnector(), $query);
        $prodotti=array();
        if($result){
            while($obj = $result->fetch_assoc()){
                $prodotto=new Prodotto($obj['codProdotto'], $obj['marca'],$obj['modello'] ,$obj['prezzo_IN'], $obj['prezzo_OUT'], $obj['quantita'], $obj['categoria'], $obj['descrizione'],$obj['immagine']);
                $prodotti[]=$prodotto;
            }
        }
        
        
        return $prodotti;
        
    }

}