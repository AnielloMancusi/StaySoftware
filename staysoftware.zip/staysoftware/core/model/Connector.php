<?php
/**
 * Created by PhpStorm.
 * User: Vik10
 * Date: 12/11/2018
 * Time: 11:05
 */

class Connector
{
    public static function getConnector() {
        $host = 'localhost';
        $user = 'root';
        $pass = 'asdrofl123';
        $db = 'staysoftware';
        return new mysqli($host, $user, $pass, $db);
    }


}