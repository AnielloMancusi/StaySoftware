<?php
/**
 * Created by PhpStorm.
 * User: Vik10
 * Date: 01/03/2019
 * Time: 14:19
 */

include_once "../beans/Riparazione.php";
include_once "Connector.php";
include_once "../beans/User.php";

session_start();


class RiparazioneModel
{

    public function __construct()
    {
    }


    public function insertPreventivo($preventivo){

        $codUtente= $_SESSION["codUtente"];

        $insert_query = "INSERT INTO riparazione(idR, descrizione, prezzo, stato, codUt) VALUES (NULL , '%s', '%d', 
                        '%s', '%d')";
        $query = sprintf($insert_query, $preventivo->getDescrizione(), $preventivo->getPrezzo(), $preventivo->getStato(), $codUtente);
    
        if (!mysqli_query(Connector::getConnector(), $query)) {
            echo("Error".mysqli_error(Connector::getConnector())."\n");
        }
    }


    public function getAllRiparazioni(){
        $select_query = "SELECT * FROM riparazione";
        $result = mysqli_query(Connector::getConnector(), $select_query);
        $users = array();
        if($result){
            while($obj = $result->fetch_assoc()){
                $user = new User($obj['idR'], $obj['descrizione'], $obj['prezzo'], $obj['stato'], $obj['codUt']);
                $users[] = $user;
            }
        }
        return $users;
    }


   

    public function updatePreventivo($prezzo_preventivo,$stato_preventivo,$idR_preventivo){
        $update_query = "UPDATE riparazione SET prezzo= '%d', stato= '%s' WHERE idR = '%s' ";
        $query = sprintf($update_query,$prezzo_preventivo, $stato_preventivo, $idR_preventivo);
        $result = mysqli_query(Connector::getConnector(), $query);
        if($result){
            return true;
        }
        return false;

    }

    public function accettaPreventivo($idR_preventivo,$stato_preventivo) {
        $update_query = "UPDATE riparazione SET stato= '%s' WHERE idR = '%s' ";
        $query = sprintf($update_query, $stato_preventivo, $idR_preventivo);
      
        $result = mysqli_query(Connector::getConnector(), $query);
        if($result){
            return true;
        }
        return false;

    }
    public function cambiaStatoRiparazione($idR_riparazione,$stato_riparazione) {
        $update_query = "UPDATE riparazione SET stato= '%s' WHERE idR = '%s' ";
        $query = sprintf($update_query, $idR_riparazione, $stato_riparazione);
       
        $result = mysqli_query(Connector::getConnector(), $query);
        if($result){
            return true;
        }
        return false;
        
    }


}