<?php

include_once "../beans/Prodotto.php";
include_once "../model/ProdottoModel.php";
session_start();



$prodottoModel= new ProdottoModel();
$prodotto=$prodottoModel;

if(($_POST["quantita_prodotto"])>1 && strlen($_POST["quantita_prodotto"])<9999) {
    $quantita=$prodotto->getProductByCod($_POST["aggiornaQuantita"])->getQuantita();
    if($prodottoModel->updateQuantita($_POST["aggiornaQuantita"], $_POST["quantita_prodotto"]+$quantita)) {
        echo '<script language=javascript>alert("Quantita prodotto aggiornata!")</script>';
        echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
        
    } 
}else {
    echo '<script language=javascript>alert("Quantita prodotto non aggiornata aggiornata!")</script>';
    echo '<script language=javascript>document.location.href="../view/aggiorna_quantita.php"</script>';
}
