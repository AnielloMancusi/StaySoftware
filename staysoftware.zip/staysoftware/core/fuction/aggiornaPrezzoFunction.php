<?php

include_once "../beans/Prodotto.php";
include_once "../model/ProdottoModel.php";
session_start();


$prodottoModel= new ProdottoModel();
$prodotto = $prodottoModel;
if(($_POST["prezzo_prodotto"])>=$prodotto->getProductByCod($_POST["prodottoUP"])->getPrezzoIN()) {
    if(preg_match("/^(\d*)[0-9]$/", $_POST["prezzo_prodotto"]) && strlen($_POST["prezzo_prodotto"])>1 &&  strlen($_POST["prezzo_prodotto"])<5){
        if($prodottoModel->updatePrezzoOUT($_POST["prodottoUP"], $_POST["prezzo_prodotto"])) {
            echo '<script language=javascript>alert("Prezzo prodotto aggiornato!")</script>';
            echo '<script language=javascript>document.location.href="../view/gestione_magazzino.php?mag=0"</script>';
            
        }
    } else {
        echo '<script language=javascript>alert("Inserire un valore numerico!")</script>';
        echo '<script language=javascript>document.location.href="../view/aggiorna_prezzo.php"</script>';
    }

} else {
    echo '<script language=javascript>alert("Prezzo non aggiornato!")</script>';
    echo '<script language=javascript>document.location.href="../view/aggiorna_prezzo.php"</script>';
}
