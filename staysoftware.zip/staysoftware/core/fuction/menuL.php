<?php 
include_once '../model/ProdottoModel.php';
    $codBud=$_COOKIE['login'];
    $conta=0;
    
    if(isset($_COOKIE["carrello"])!=null){
        $carrello=$_COOKIE["carrello"];
        $prodotti=(explode(',', $carrello));
        $conta=0;
        $conta = count($prodotti);
        $_SESSION["contaCarr"]=$conta/4;
        $empy_cart=false;
        
    } else {
        $empy_cart=true;
    }
?>
        		
        		
        		<div class="top_bar">
			<div class="container">
				<div class="row">
					<div class="col d-flex flex-row">
						<div class="top_bar_contact_item"><div class="top_bar_icon"><img src="../assets/images/phone.png" alt=""></div>+39 081 99 99 99</div>
						<div class="top_bar_contact_item"><div class="top_bar_icon"><img src="../assets/images/mail.png" alt=""></div><a href="assistenza@staysoftware.it">assistenza@staysoftware.it</a></div>
						<div class="top_bar_content ml-auto">
							
							<div class="top_bar_user">
								<div class="user_icon"><img src="../assets/images/user.svg" alt=""></div>
								 <div><a href="../view/profiloUtente.php"><?php 	echo $codBud;?></a></div>
        						 <div><a href="../control/LogoutControl.php">Log out</a></div>
							</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		

		<!-- Header Main -->

		<div class="header_main">
			<div class="container">
				<div class="row">

					<!-- Logo -->
					<div class="col-lg-2 col-sm-3 col-3 order-1">
						<div class="logo_container">
							<div class="logo"><a href="../view/home.php"><img src="../assets/images/logo1.png" width="290" height="200"></a></div>
						</div>
					</div>

					<!-- Search -->
					<div class="col-lg-6 col-12 order-lg-2 order-3 text-lg-left text-right">
						<div class="header_search">
							<div class="header_search_content">
								<div class="header_search_form_container">
									<form action="#" class="header_search_form clearfix">
										<input type="search" required="required" class="header_search_input" placeholder="Cerca">
										<div class="custom_dropdown">
											<div class="custom_dropdown_list">
												<span class="custom_dropdown_placeholder clc">Tutte le categorie</span>
												<i class="fas fa-chevron-down"></i>
												<ul class="custom_list clc">
													<li><a class="clc" href="#">Computer</a></li>
													<li><a class="clc" href="#">Smartphone</a></li>
													<li><a class="clc" href="#">Tv & Audio</a></li>
													<li><a class="clc" href="#">Video Games & Console</a></li>
												</ul>
											</div>
										</div>
										<button type="submit" class="header_search_button trans_300" value="Submit"><img src="../assets/images/search.png" alt=""></button>
									</form>
								</div>
							</div>
						</div>
					</div>

					<!-- Wishlist -->
					<div class="col-lg-4 col-9 order-lg-3 order-2 text-lg-left text-right">
						<div class="wishlist_cart d-flex flex-row align-items-center justify-content-end">


							<!-- Cart -->
							<div class="cart">
								<div class="cart_container d-flex flex-row align-items-center justify-content-end">
									<div class="cart_icon">
										<img src="../assets/images/cart.png" alt="">
										<div class="cart_count"><span><?php echo $conta/4;?></span></div>
									</div>
									<div class="cart_content">
										<div class="cart_text"><a href="../view/cart.php">Carrello</a></div>
										<div class="cart_price"></div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Main Navigation -->

		<nav class="main_nav">
			<div class="container">
				<div class="row">
					<div class="col">

						<div class="main_nav_content d-flex flex-row">

							<!-- Categories Menu -->

							<div class="cat_menu_container">
								<div class="cat_menu_title d-flex flex-row align-items-center justify-content-start">
									<div class="cat_burger"><span></span><span></span><span></span></div>
									<div class="cat_menu_text">categorie</div>
								</div>

								<ul class="cat_menu">
									<li><a href="../view/tabella_prodotti.php?categoria=computer">Computer<i class="fas fa-chevron-right ml-auto"></i></a></li>
									<li><a href="../view/tabella_prodotti.php?categoria=smartphone">Smartphone<i class="fas fa-chevron-right"></i></a></li>
									<li><a href="../view/tabella_prodotti.php?categoria=tvaudio">TV & Audio<i class="fas fa-chevron-right"></i></a></li>
									
									<li><a href="../view/tabella_prodotti.php?categoria=console">Video Games & Console<i class="fas fa-chevron-right"></i></a></li>
									
								</ul>
							</div>

							
                         <!-- Main Nav Menu -->

							<div class="main_nav_menu ml-auto">
								<ul class="standard_dropdown main_nav_dropdown">
									
									
									<li class="hassubs">
										<a href="../view/richiesta_preventivo.php">Riparazioni<i class="fas fa-chevron-down"></i></a>
										<ul>
											<li><a href="../view/richiesta_preventivo.php">Preventivo<i class="fas fa-chevron-down"></i></a></li>
											<li><a href="controlla_richieste.php">Stato Riparazione<i class="fas fa-chevron-down"></i></a></li>
										</ul>
									</li>
									
							</div>

							<!-- Menu Trigger -->

							<div class="menu_trigger_container ml-auto">
								<div class="menu_trigger d-flex flex-row align-items-center justify-content-end">
									<div class="menu_burger">
										<div class="menu_trigger_text">Menu</div>
										<div class="cat_burger menu_burger_inner"><span></span><span></span><span></span></div>
									</div>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
		</nav>

		<div class="page_menu">
			<div class="container">
				<div class="row">
					<div class="col">

						<div class="page_menu_content">

							<div class="page_menu_search">
								<form action="#">
									<input type="search" required="required" class="page_menu_search_input" placeholder="Search for products...">
								</form>
							</div>
				
							<div class="menu_contact">
								<div class="menu_contact_item"><div class="menu_contact_icon"><img src="../assets/images/phone_white.png" alt=""></div>+38 068 005 3570</div>
								<div class="menu_contact_item"><div class="menu_contact_icon"><img src="../assets/images/mail_white.png" alt=""></div><a href="mailto:fastsales@gmail.com">fastsales@gmail.com</a></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>


<script src="../assets/js/jquery-3.3.1.min.js"></script>
<script src="../assets/styles/bootstrap4/popper.js"></script>
<script src="../assets/styles/bootstrap4/bootstrap.min.js"></script>
<script src="../assets/plugins/greensock/TweenMax.min.js"></script>
<script src="../assets/plugins/greensock/TimelineMax.min.js"></script>
<script src="../assets/plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="../assets/plugins/greensock/animation.gsap.min.js"></script>
<script src="../assets/plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="../assets/plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="../assets/plugins/slick-1.8.0/slick.js"></script>
<script src="../assets/plugins/easing/easing.js"></script>
<script src="../assets/js/custom.js"></script>

	