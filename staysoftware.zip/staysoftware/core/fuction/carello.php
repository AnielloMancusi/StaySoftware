<?php 

include_once "../beans/Prodotto.php";
include_once "../model/ProdottoModel.php";
session_start();


$codProd=$_SESSION['idB'];

$prodottoModel=new ProdottoModel();

if(isset($_POST["quantity_input"]) && $_POST["quantity_input"] != null){
    $quantita = strip_tags($_POST["quantity_input"]);
     $_SESSION["quantita"]=$quantita;
      $quantProd=$prodottoModel->getProductByCod($codProd)->getQuantita();
    if($quantProd>=$quantita){
        
        $prodotto=$prodottoModel->getProductByCod($codProd);
        $marca= $prodotto->getMarca();
        $modello= $prodotto->getModello();
        $prezzo=$prodotto->getPrezzoOUT();
        
        if(isset($_COOKIE["carrello"])) {
            
            $carello2=$_COOKIE["carrello"];
            $carrello=$carello2.$codProd.','.$modello.','.$quantita.','.$prezzo.',';            
            setcookie("carrello", $carrello, 0, "/");
        } else {
            
            $carrello=$codProd.','.$modello.','.$quantita.','.$prezzo.',';
           
            setcookie("carrello", $carrello, 0, "/");
        }
        
        
        echo '<script language=javascript>document.location.href="../view/cart.php"</script>';
    } else {
        if($quantProd==0) {
            echo '<script language=javascript>alert("Prodotto non disponibile!")</script>';
            echo '<script language=javascript>document.location.href="../view/cart.php"</script>';
        }
        if($quantita>$quantProd) {
            echo '<script language=javascript>alert("Non disponiamo di questa quantità di prodotto")</script>';
            echo '<script language=javascript>document.location.href="../view/cart.php"</script>';
        }
        if(!preg_match("/^(\d*)-(\d*)[0-9]$/", $quantita) ){
            echo '<script language=javascript>alert("Inserisci una quantità valida")</script>';
            echo '<script language=javascript>document.location.href="../view/cart.php"</script>';
        }
    }
        $validate=true;
        
    }
    
   

?>