-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Ago 25, 2020 alle 09:52
-- Versione del server: 10.3.15-MariaDB
-- Versione PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `staysoftware`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `ordine`
--

CREATE TABLE `ordine` (
  `idO` int(10) NOT NULL,
  `idP` int(10) DEFAULT NULL,
  `codUt` int(10) DEFAULT NULL,
  `stato` varchar(50) DEFAULT NULL,
  `prezzo` float DEFAULT NULL,
  `data` date DEFAULT NULL,
  `quantita` int(3) DEFAULT NULL,
  `via` varchar(20) DEFAULT NULL,
  `provinciaSped` varchar(3) NOT NULL,
  `comuneSped` varchar(150) NOT NULL,
  `capSped` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `ordine`
--

INSERT INTO `ordine` (`idO`, `idP`, `codUt`, `stato`, `prezzo`, `data`, `quantita`, `via`, `provinciaSped`, `comuneSped`, `capSped`) VALUES
(1, 33, 2, 'in spedizione', 1050, '2019-11-05', 1, 'AESTRYD', 'SA', 'arestyu', 687354),
(2, 33, 2, 'in spedizione', 1050, '2019-11-06', 1, 'AESTRYD', 'SA', 'arestyu', 687354),
(4, 30, 2, 'in spedizione', 480, '2019-11-06', 1, 'AESTRYD', 'SA', 'arestyu', 687354),
(6, 31, 2, 'in spedizione', 750, '2019-11-06', 1, 'AESTRYD', 'SA', 'arestyu', 687354),
(7, 33, 2, 'in spedizione', 1050, '2019-11-06', 1, 'AESTRYD', 'SA', 'arestyu', 687354),
(8, 42, 2, 'in spedizione', 200, '2019-11-06', 1, 'AESTRYD', 'SA', 'arestyu', 687354),
(9, 30, 2, 'in spedizione', 480, '2019-11-06', 1, 'AESTRYD', 'SA', 'arestyu', 687354),
(10, 29, 2, 'in spedizione', 330, '2019-11-06', 1, 'AESTRYD', 'SA', 'arestyu', 687354),
(11, 28, 2, 'in spedizione', 2000, '2019-11-06', 1, 'AESTRYD', 'SA', 'arestyu', 687354),
(12, 33, 2, 'in spedizione', 1050, '2019-11-07', 1, 'AESTRYD', 'SA', 'arestyu', 687354),
(13, 28, 4, 'in spedizione', 2000, '2019-11-07', 1, 'via dalle scatole', 'sal', 'sarno', 84087),
(14, 44, 2, 'in spedizione', 809, '2019-11-07', 1, 'AESTRYD', 'SA', 'arestyu', 687354),
(15, 28, 2, 'in spedizione', 2000, '2019-11-08', 1, 'AESTRYD', 'SA', 'arestyu', 687354);

-- --------------------------------------------------------

--
-- Struttura della tabella `prodotto`
--

CREATE TABLE `prodotto` (
  `codProdotto` int(10) NOT NULL,
  `marca` varchar(10) NOT NULL,
  `modello` varchar(15) NOT NULL,
  `prezzo_IN` int(5) NOT NULL,
  `prezzo_OUT` int(5) NOT NULL,
  `quantita` int(5) DEFAULT NULL,
  `categoria` varchar(10) DEFAULT NULL,
  `descrizione` varchar(200) DEFAULT NULL,
  `immagine` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `prodotto`
--

INSERT INTO `prodotto` (`codProdotto`, `marca`, `modello`, `prezzo_IN`, `prezzo_OUT`, `quantita`, `categoria`, `descrizione`, `immagine`) VALUES
(28, 'Apple', 'iMac', 1800, 2000, 2, 'computer', 'Display Retina 5K da 27\" (diagonale) con risoluzione 5120x2880\r\nDesign incredibilmente sottile: solo 5 mm lungo i bordi\r\nProcessore Intel Core i5 6-core di ottava o nona generazione\r\nProcessore grafic', '../assets/images/Apple_iMac.jpg'),
(29, 'Apple', 'iPhone 6s', 300, 330, 5, 'smartphone', '\r\n    Display Retina HD da 4,7\"\r\n    Fotocamera da 12MP con registrazione video 4K\r\n    Videocamera FaceTime HD (foto da 5MP) con Retina Flash\r\n    Touch ID per lâ€™autenticazione sicura e Apple Pay\r\n', '../assets/images/Apple_iPhone_6s.jpg'),
(30, 'Apple', 'iPhone7', 450, 480, 6, 'smartphone', '\r\n    Fotocamera da 12MP\r\n    Zoom digitale fino a 5x\r\n    Rating IP67 - Resistenza ad acqua, schizzi e polvere\r\n    Display Retina HD - Widescreen retroilluminato LED da 4,7\" (diagonale)\r\n', '../assets/images/Apple_iPhone7.jpg'),
(31, 'Apple', 'iPhoneXR', 700, 750, 2, 'smartphone', '\r\n    Display Liquid Retina (LCD) da 6,1\"\r\n    Resistenza a polvere e acqua di grado IP67 (profonditÃ  massima di 1 metro fino a 30 minuti)\r\n    Fotocamera da 12MP con stabilizzazione ottica dellâ€™im', '../assets/images/Apple_iPhoneXR.jpg'),
(32, 'Apple', 'iPhoneXS Max', 1000, 1200, 1, 'smartphone', '\r\n    Display Super Retina (OLED) da 6,5\" con HDR1\r\n    Resistenza a polvere e acqua di grado IP68 (profonditÃ  massima di 2 metri fino a 30 minuti)2\r\n    Doppia fotocamera da 12MP con doppia stabiliz', '../assets/images/Apple_iPhoneXS_Max.jpg'),
(33, 'Apple', 'Macbook Air', 950, 1050, 3, 'computer', '\r\n    Spettacolare display Retina da 13,3\"\r\n    Touch ID\r\n    Processore Intel Core i5 dual-core di ottava generazione\r\n    Intel UHD Graphics 617\r\n    Archiviazione SSD veloce\r\n    8GB di memoria\r\n  ', '../assets/images/Apple_MacBook_Air.jpg'),
(34, 'Apple', 'Macbook Pro', 1800, 2000, 1, 'computer', '\r\n    Processore Intel Core i5 quadâ€‘core di ottava generazione\r\n    Spettacolare display Retina con tecnologia True Tone\r\n    Touch Bar e Touch ID\r\n    Intel Iris Plus Graphics 655\r\n    Archiviazion', '../assets/images/Apple_MacBook_Pro.jpg'),
(35, 'HP', 'Pavilion x360', 470, 500, 2, 'computer', ' Penna Stilo Attiva inclusa\r\nIntel Pentium Gold 4415U, 2,3 GHz, 2 MB di cache, 2 core\r\n8 GB di SDRAM DDR4-2133 (1 x 8 GB); velocitÃ  di trasferimento fino a 2133 MT/s.\r\nDisplay 14â€ HD SVA micro-edge', '../assets/images/HP_Pavilion_x360.jpg'),
(36, 'Huawei', 'Mediapad T3', 100, 130, 5, 'smartphone', ' Display IPS 9.6â€ (1280 x 800), corpo in alluminio anodizzato di derivazione spaziale\r\nFotocamera frontale da 2 MP e fotocamera posteriore da 5 MP\r\nProcessore Quad-core (1.4G Hz), 2 GB + 16 GB, Andr', '../assets/images/Huawei_Mediapad_T3.jpg'),
(37, 'JBL', 'E55BT', 70, 100, 7, 'tvaudio', ' Stacca la spina: con le cuffie over-ear di JBL ti godi la tua musica preferita e il piacere del tipico suono JBL in ottimo comfort, grazie al rivestimento dellâ€™archetto e ai padiglioni imbottiti\r\nB', '../assets/images/JBL_E55BT.jpg'),
(38, 'Lenovo', 'Ideapad S130', 200, 230, 3, 'computer', ' Processore Intel Celeron N4000\r\nDisplay da 14 pollici con risoluzione 1280 x 720 pixel, Led HD TN anti-riflesso, che offre bassi tempi di risposta e alti refresh rate delle immagini\r\nTempo di Rispost', '../assets/images/Lenovo_Ideapad_S130.jpg'),
(39, 'LG', '49UK6300MLB', 300, 340, 1, 'tvaudio', 'televisore 124,5 cm (49\") 4K Ultra HD Smart TV Wi-Fi Nero ', '../assets/images/LG_49UK6300MLB.jpg'),
(40, 'Shure', 'SRH440', 40, 70, 4, 'tvaudio', ' Perfetta per le registrazioni in studio e lâ€™home recording, riproduce il suono in maniera precisa su un ampio spettro di frequenze\r\nImpedenza e tenuta in potenza ottimizzate per lâ€™uso con i dispo', '../assets/images/Shure_SRH440.jpg'),
(41, 'Microsoft', 'Xbox One S', 120, 160, 1, 'console', 'Tecnologia 4K Ultra HD Blu-ray e streaming\r\nOttima grafica con tecnologia HDR\r\nController con impugnatura antiscivolo\r\nAudio immersivo grazie a Dolby Atmos e DTS: X\r\nÃˆ ottima per giocare, guardare le', '../assets/images/Xbox_One_S.jpg'),
(42, 'Sony', 'PlayStation 4 ', 180, 200, 7, 'console', '500 Gb B Chassis ', '../assets/images/PlayStation_4.jpg'),
(43, 'Samsung', 'galaxy', 200, 250, 10, 'computer', 'smartphone buono', '../assets/images/samsung_galaxy.jpg'),
(44, 'Apple', 'Iphone 11', 800, 809, 14, 'smartphone', '\r\n    Resistente alla polvere e allâ€™acqua (2 metri fino a 30 minuti, IP68)\r\n    Sistema a doppia fotocamera da 12MP (ultra-grandangolo e grandangolo) con modalitaÌ€ Notte, modalitaÌ€ Ritratto e regi', '../assets/images/Apple_Iphone_11.png');

-- --------------------------------------------------------

--
-- Struttura della tabella `riparazione`
--

CREATE TABLE `riparazione` (
  `idR` int(10) NOT NULL,
  `descrizione` varchar(200) NOT NULL,
  `prezzo` int(5) DEFAULT NULL,
  `stato` varchar(20) NOT NULL,
  `codUt` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `codUtente` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `cognome` varchar(100) NOT NULL,
  `codFiscale` varchar(20) NOT NULL,
  `dataNascita` date NOT NULL,
  `provinciaNascita` varchar(3) NOT NULL,
  `comuneNascita` varchar(150) NOT NULL,
  `nazioneNascita` varchar(100) NOT NULL,
  `via` varchar(150) NOT NULL,
  `provinciaResidenza` varchar(3) NOT NULL,
  `comuneResidenza` varchar(150) NOT NULL,
  `cap` int(11) NOT NULL,
  `sesso` varchar(6) NOT NULL,
  `telefono1` varchar(15) DEFAULT NULL,
  `telefono2` varchar(15) DEFAULT NULL,
  `admin` varchar(2) DEFAULT NULL,
  `mail` varchar(70) DEFAULT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`codUtente`, `nome`, `cognome`, `codFiscale`, `dataNascita`, `provinciaNascita`, `comuneNascita`, `nazioneNascita`, `via`, `provinciaResidenza`, `comuneResidenza`, `cap`, `sesso`, `telefono1`, `telefono2`, `admin`, `mail`, `password`) VALUES
(1, 'Aniello', 'Mancusi', 'MNCNLL94R08F912S', '1994-10-08', 'Sar', 'nocera inferiore', 'Italia', 'Via Sarno Striano 62', 'Sal', 'sarno', 84087, 'maschi', '3291599826', '', 'si', 'aniellom18@gmail.com', 'asdrofl123'),
(2, 'gennaro', 'franzese', 'sadfghkfgrshtdu', '2019-06-02', 'sa', 'sarno', 'AFSEGRDHTJY', 'AESTRYD', 'SA', 'arestyu', 687354, 'm', '2134657', NULL, 'no', 'ciaociao@ciao.it', 'ciao'),
(3, 'Vincenzo', 'Zito', 'ZTIVCN80A01D708D', '2019-07-03', 'For', 'wasdf', 'Italia', 'santa maria la noce n 36', 'sda', 'sadf', 3333, 'ddd', '232423423', '', 'si', 'vzito90@gmail.com', 'ciaociao'),
(4, 'Luca', 'Mancusi', 'uvhbinjcowmkdp', '2003-02-19', 'Sal', 'Salerno', 'italia', 'via dalle scatole', 'sal', 'sarno', 84087, 'maschi', '3291599826', '', 'no', 'luca@mancusi.it', 'luca'),
(5, 'a', 'Mancusi', 'MNCNLL', '1994-10-08', 'Sal', 'nocera', 'italia', 'via sarno striano 70', 'sa', 'sarno', 84087, 'maschi', '3291599826', '', 'no', 'ciao@ciao.it', 'ciao');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `ordine`
--
ALTER TABLE `ordine`
  ADD PRIMARY KEY (`idO`),
  ADD KEY `idP` (`idP`),
  ADD KEY `codUt` (`codUt`);

--
-- Indici per le tabelle `prodotto`
--
ALTER TABLE `prodotto`
  ADD PRIMARY KEY (`codProdotto`);

--
-- Indici per le tabelle `riparazione`
--
ALTER TABLE `riparazione`
  ADD PRIMARY KEY (`idR`),
  ADD KEY `codUt` (`codUt`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`codUtente`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `ordine`
--
ALTER TABLE `ordine`
  MODIFY `idO` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT per la tabella `prodotto`
--
ALTER TABLE `prodotto`
  MODIFY `codProdotto` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT per la tabella `riparazione`
--
ALTER TABLE `riparazione`
  MODIFY `idR` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `codUtente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `ordine`
--
ALTER TABLE `ordine`
  ADD CONSTRAINT `ordine_ibfk_1` FOREIGN KEY (`idP`) REFERENCES `prodotto` (`codProdotto`),
  ADD CONSTRAINT `ordine_ibfk_2` FOREIGN KEY (`codUt`) REFERENCES `utenti` (`codUtente`);

--
-- Limiti per la tabella `riparazione`
--
ALTER TABLE `riparazione`
  ADD CONSTRAINT `riparazione_ibfk_1` FOREIGN KEY (`codUt`) REFERENCES `utenti` (`codUtente`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
