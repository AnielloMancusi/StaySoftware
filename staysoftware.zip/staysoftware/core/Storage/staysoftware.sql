
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `staydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE utenti(
  codUtente INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(100) NOT NULL,
  cognome VARCHAR(100) NOT NULL,
  codFiscale VARCHAR(20) NOT NULL,
  dataNascita DATE NOT NULL,
  provinciaNascita VARCHAR (3) NOT NULL,
  comuneNascita VARCHAR(150) NOT NULL,
  nazioneNascita VARCHAR(100) NOT NULL,
  via VARCHAR(150) NOT NULL,
  provinciaResidenza VARCHAR (3) NOT NULL,
  comuneResidenza VARCHAR(150) NOT NULL,
  cap INT NOT NULL,
  sesso VARCHAR (6) NOT NULL,
  telefono1 VARCHAR(15),
  telefono2 VARCHAR(15),
  admin VARCHAR(2),
  mail VARCHAR(70),
  password VARCHAR(15) NOT NULL
);

CREATE TABLE prodotto
( codProdotto int(10) PRIMARY key AUTO_INCREMENT,
  marca varchar(10) not null,
  modello varchar(15) not null,
  prezzo_IN int(5) not null,
  prezzo_OUT int(5) not null,
  quantita int(5),
  categoria varchar(10),
  descrizione varchar(200)
);

create table riparazione 
( idR int(10) PRIMARY key AUTO_INCREMENT,
  descrizione varchar(200) not null,
  prezzo int(5),
  stato varchar(20) not null,
  codUt int(10),
  foreign key(codUt) references utenti(codUtente)
  );
  
  
   create table ordine
 ( idO int(10) PRIMARY key AUTO_INCREMENT,
 idP int(10),
 	 codUt int(10),
   stato varchar(50),
   prezzo float(5),
   data date,
   quantita int(3),
  via varchar (20),
  provinciaSped VARCHAR (3) NOT NULL,
  comuneSped VARCHAR(150) NOT NULL,
  capSped INT NOT NULL,
   foreign key(idP) references prodotto(codProdotto),
   foreign key(codUt) references utenti(codUtente)
);


